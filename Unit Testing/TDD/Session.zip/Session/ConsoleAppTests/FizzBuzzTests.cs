using ConsoleApp;
using System.Text.RegularExpressions;

namespace ConsoleAppTests
{
    public class FizzBuzzTests
    {
        [Theory]
        [InlineData(1, "1")]
        [InlineData(17, "17")]
        public void Print_NumberNotDivisibleBy3And5_PrintNumber(int number, string expectedResult)
        {
            var result = FizzBuzz.Print(number);

            Assert.Matches(new Regex($"^{expectedResult}$"), result);
        }


        [Theory]
        [InlineData(3, "Fizz")]
        [InlineData(6, "Fizz")]
        [InlineData(27, "Fizz")]
        public void Print_NumberDivisibleBy3_PrintFizz(int number, string expectedResult)
        {
            var result = FizzBuzz.Print(number);

            Assert.Matches(new Regex($"^{expectedResult}$"), result);
        }

        [Theory]
        [InlineData(20, "Buzz")]
        [InlineData(100, "Buzz")]
        [InlineData(40, "Buzz")]
        public void Print_NumberDivisibleBy5_PrintBuzz(int number, string expectedResult)
        {
            var result = FizzBuzz.Print(number);

            Assert.Matches(new Regex($"^{expectedResult}$"), result);
        }

        [Theory]
        [InlineData(15, "FizzBuzz")]
        [InlineData(90, "FizzBuzz")]
        [InlineData(120, "FizzBuzz")]
        public void Print_NumberDivisibleBy3And5_PrintBuzz(int number, string expectedResult)
        {
            var result = FizzBuzz.Print(number);

            Assert.Matches(new Regex($"^{expectedResult}$"), result);
        }
    }
}
