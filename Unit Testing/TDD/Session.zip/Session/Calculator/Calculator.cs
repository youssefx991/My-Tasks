﻿namespace Calculator
{
    public class Calculator
    {
        private readonly List<int> _numbers;

        public Calculator()
        {
            _numbers = new List<int>();
        }
        public void Enter(int number)
        {
            _numbers.Add(number);
        }

        public int Add()
        {
            return _numbers.Sum();
        }
    }
}
