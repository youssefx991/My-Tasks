using System;
using Reqnroll;
using Xunit;

namespace CalculatorTests.StepDefinitions
{
    [Binding]
    public class CalculatorAdditionStepDefinitions
    {
        private readonly Calculator.Calculator _calculator;
        private int sumResult = 0;

        public CalculatorAdditionStepDefinitions(Calculator.Calculator calculator)
        {
            _calculator = calculator;
        }

        [Given("User Enter {int} into calculator")]
        public void GivenUserEnterIntoCalculator(int p0)
        {
            _calculator.Enter(p0);
        }

        [When("User press add")]
        public void WhenUserPressAdd()
        {
            sumResult = _calculator.Add();
        }

        [Then("Sum should be {int}")]
        public void ThenSumShouldBe(int p0)
        {
            Assert.Equal(p0, sumResult);
        }

    }
}
