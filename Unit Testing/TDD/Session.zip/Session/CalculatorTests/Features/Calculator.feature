Feature: Calculator

Adding multiple numbers

@add @calculator
Scenario: Add two numbers
	Given User Enter 50 into calculator
	And User Enter 20 into calculator
	And User Enter 10 into calculator
	When User press add
	Then Sum should be 80