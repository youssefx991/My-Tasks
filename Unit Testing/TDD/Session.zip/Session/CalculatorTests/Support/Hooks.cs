﻿using Reqnroll.BoDi;
using System;
using System.Collections.Generic;
using System.Text;

namespace CalculatorTests.Support
{
    [Binding]
    internal class Hooks
    {
        private readonly IObjectContainer _objectContainer;

        public Hooks(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
            _objectContainer.RegisterInstanceAs(new Calculator.Calculator());
        }
    }
}
