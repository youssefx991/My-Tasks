import logo from './logo.svg';
import './App.css';
import {TrackingServiceClient} from './generated/tracking_grpc_web_pb';
import {TrackingMessage, Location} from './generated/tracking_pb';

function App() {

  const client = new TrackingServiceClient("https://localhost:7238");

  const sendMessage = function() {

    let message = new TrackingMessage();

    message.setDeviceid(100);

    const location = new Location();
    location.setLat(30);
    location.setLong(31);
    message.setLocation(location);

    message.setSpeed(120);

    client.sendMessage(message, {}, (err, response) => {

      if (err) {
        console.error(err);
      }
      else {
        console.log(response.getSuccess());
      }

    });
  };


  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <button type="button" onClick={sendMessage}>Send Message</button>
      </header>
    </div>
  );
}

export default App;
