/*! modernizr 3.3.1 (Custom Build) | MIT *
 * https://modernizr.com/download/?-adownload-ambientlight-animation-apng-appearance-applicationcache-atobbtoa-audio-audioloop-audiopreload-backdropfilter-backgroundblendmode-backgroundcliptext-backgroundsize-batteryapi-bdi-beacon-bgpositionshorthand-bgpositionxy-bgrepeatspace_bgrepeatround-bgsizecover-blobconstructor-bloburls-blobworkers-borderimage-borderradius-boxshadow-boxsizing-canvas-canvasblending-canvastext-canvaswinding-capture-checked-classlist-contains-contenteditable-contextmenu-cookies-cors-createelementattrs_createelement_attrs-cryptography-cssall-cssanimations-csscalc-csschunit-csscolumns-cssescape-cssexunit-cssfilters-cssgradients-csshairline-csshyphens_softhyphens_softhyphensfind-cssinvalid-cssmask-csspointerevents-csspositionsticky-csspseudoanimations-csspseudotransitions-cssreflections-cssremunit-cssresize-cssscrollbar-csstransforms-csstransforms3d-csstransitions-cssvalid-cssvhunit-cssvmaxunit-cssvminunit-cssvwunit-cubicbezierrange-customevent-customprotocolhandler-dart-datachannel-datalistelem-dataset-datauri-dataview-dataworkers-details-devicemotion_deviceorientation-directory-display_runin-displaytable-documentfragment-ellipsis-emoji-es5-es5array-es5date-es5function-es5object-es5string-es5syntax-es5undefined-es6array-es6collections-es6math-es6number-es6object-es6string-eventlistener-eventsource-exiforientation-fetch-fileinput-filereader-filesystem-flash-flexbox-flexboxlegacy-flexboxtweener-flexwrap-fontface-forcetouch-formattribute-formvalidation-framed-fullscreen-gamepads-generatedcontent-generators-geolocation-getrandomvalues-getusermedia-hashchange-hidden-hiddenscroll-history-hsla-htmlimports-ie8compat-imgcrossorigin-indexeddb-indexeddbblob-inlinesvg-input-inputformaction-inputformenctype-inputformmethod-inputformtarget-inputtypes-intl-jpeg2000-jpegxr-json-lastchild-ligatures-localizednumber-localstorage-lowbandwidth-lowbattery-matchmedia-mathml-mediaqueries-microdata-multiplebgs-mutationobserver-notification-nthchild-objectfit-olreversed-oninput-opacity-outputelem-overflowscrolling-pagevisibility-peerconnection-performance-picture-placeholder-pointerevents-pointerlock-postmessage-preserve3d-progressbar_meter-promises-proximity-queryselector-quotamanagement-regions-requestanimationframe-requestautocomplete-rgba-ruby-sandbox-scriptasync-scriptdefer-scrollsnappoints-seamless-search-serviceworker-sessionstorage-shapes-sharedworkers-siblinggeneral-sizes-smil-speechrecognition-speechsynthesis-srcdoc-srcset-strictmode-stylescoped-subpixelfont-supports-svg-svgasimg-svgclippaths-svgfilters-svgforeignobject-target-template-templatestrings-textalignlast-textareamaxlength-textshadow-texttrackapi_track-time-todataurljpeg_todataurlpng_todataurlwebp-touchevents-transferables-typedarrays-unicode-unicoderange-unknownelements-urlparser-userdata-userselect-vibrate-video-videoautoplay-videoloop-videopreload-vml-webaudio-webgl-webglextensions-webintents-webp-webpalpha-webpanimation-webplossless_webp_lossless-websockets-websocketsbinary-websqldatabase-webworkers-willchange-wrapflow-xdomainrequest-xhr2-xhrresponsetype-xhrresponsetypearraybuffer-xhrresponsetypeblob-xhrresponsetypedocument-xhrresponsetypejson-xhrresponsetypetext-addtest-atrule-domprefixes-hasevent-mq-prefixed-prefixedcss-prefixedcssvalue-prefixes-setclasses-shiv-testallprops-testprop-teststyles !*/
! function (window, document, undefined) {
    function is(A, e) {
        return typeof A === e
    }

    function testRunner() {
        var A, e, t, n, r, i, o;
        for (var d in tests)
            if (tests.hasOwnProperty(d)) {
                if (A = [], e = tests[d], e.name && (A.push(e.name.toLowerCase()), e.options && e.options.aliases && e.options.aliases.length))
                    for (t = 0; t < e.options.aliases.length; t++) A.push(e.options.aliases[t].toLowerCase());
                for (n = is(e.fn, "function") ? e.fn() : e.fn, r = 0; r < A.length; r++) i = A[r], o = i.split("."), 1 === o.length ? Modernizr[o[0]] = n : (!Modernizr[o[0]] || Modernizr[o[0]] instanceof Boolean || (Modernizr[o[0]] = new Boolean(Modernizr[o[0]])), Modernizr[o[0]][o[1]] = n), classes.push((n ? "" : "no-") + o.join("-"))
            }
    }

    function setClasses(A) {
        var e = docElement.className,
            t = Modernizr._config.classPrefix || "";
        if (isSVG && (e = e.baseVal), Modernizr._config.enableJSClass) {
            var n = new RegExp("(^|\\s)" + t + "no-js(\\s|$)");
            e = e.replace(n, "$1" + t + "js$2")
        }
        Modernizr._config.enableClasses && (e += " " + t + A.join(" " + t), isSVG ? docElement.className.baseVal = e : docElement.className = e)
    }

    function addTest(A, e) {
        if ("object" == typeof A)
            for (var t in A) hasOwnProp(A, t) && addTest(t, A[t]);
        else {
            A = A.toLowerCase();
            var n = A.split("."),
                r = Modernizr[n[0]];
            if (2 == n.length && (r = r[n[1]]), "undefined" != typeof r) return Modernizr;
            e = "function" == typeof e ? e() : e, 1 == n.length ? Modernizr[n[0]] = e : (!Modernizr[n[0]] || Modernizr[n[0]] instanceof Boolean || (Modernizr[n[0]] = new Boolean(Modernizr[n[0]])), Modernizr[n[0]][n[1]] = e), setClasses([(e && 0 != e ? "" : "no-") + n.join("-")]), Modernizr._trigger(A, e)
        }
        return Modernizr
    }

    function createElement() {
        return "function" != typeof document.createElement ? document.createElement(arguments[0]) : isSVG ? document.createElementNS.call(document, "http://www.w3.org/2000/svg", arguments[0]) : document.createElement.apply(document, arguments)
    }

    function cssToDOM(A) {
        return A.replace(/([a-z])-([a-z])/g, function (A, e, t) {
            return e + t.toUpperCase()
        }).replace(/^-/, "")
    }

    function domToCSS(A) {
        return A.replace(/([A-Z])/g, function (A, e) {
            return "-" + e.toLowerCase()
        }).replace(/^ms-/, "-ms-")
    }

    function getBody() {
        var A = document.body;
        return A || (A = createElement(isSVG ? "svg" : "body"), A.fake = !0), A
    }

    function injectElementWithStyles(A, e, t, n) {
        var r, i, o, d, a = "modernizr",
            s = createElement("div"),
            l = getBody();
        if (parseInt(t, 10))
            for (; t--;) o = createElement("div"), o.id = n ? n[t] : a + (t + 1), s.appendChild(o);
        return r = createElement("style"), r.type = "text/css", r.id = "s" + a, (l.fake ? l : s).appendChild(r), l.appendChild(s), r.styleSheet ? r.styleSheet.cssText = A : r.appendChild(document.createTextNode(A)), s.id = a, l.fake && (l.style.background = "", l.style.overflow = "hidden", d = docElement.style.overflow, docElement.style.overflow = "hidden", docElement.appendChild(l)), i = e(s, A), l.fake ? (l.parentNode.removeChild(l), docElement.style.overflow = d, docElement.offsetHeight) : s.parentNode.removeChild(s), !!i
    }

    function contains(A, e) {
        return !!~("" + A).indexOf(e)
    }

    function roundedEquals(A, e) {
        return A - 1 === e || A === e || A + 1 === e
    }

    function nativeTestProps(A, e) {
        var t = A.length;
        if ("CSS" in window && "supports" in window.CSS) {
            for (; t--;)
                if (window.CSS.supports(domToCSS(A[t]), e)) return !0;
            return !1
        }
        if ("CSSSupportsRule" in window) {
            for (var n = []; t--;) n.push("(" + domToCSS(A[t]) + ":" + e + ")");
            return n = n.join(" or "), injectElementWithStyles("@supports (" + n + ") { #modernizr { position: absolute; } }", function (A) {
                return "absolute" == getComputedStyle(A, null).position
            })
        }
        return undefined
    }

    function testProps(A, e, t, n) {
        function r() {
            o && (delete mStyle.style, delete mStyle.modElem)
        }
        if (n = is(n, "undefined") ? !1 : n, !is(t, "undefined")) {
            var i = nativeTestProps(A, t);
            if (!is(i, "undefined")) return i
        }
        for (var o, d, a, s, l, c = ["modernizr", "tspan", "samp"]; !mStyle.style && c.length;) o = !0, mStyle.modElem = createElement(c.shift()), mStyle.style = mStyle.modElem.style;
        for (a = A.length, d = 0; a > d; d++)
            if (s = A[d], l = mStyle.style[s], contains(s, "-") && (s = cssToDOM(s)), mStyle.style[s] !== undefined) {
                if (n || is(t, "undefined")) return r(), "pfx" == e ? s : !0;
                try {
                    mStyle.style[s] = t
                } catch (u) {}
                if (mStyle.style[s] != l) return r(), "pfx" == e ? s : !0
            }
        return r(), !1
    }

    function fnBind(A, e) {
        return function () {
            return A.apply(e, arguments)
        }
    }

    function testDOMProps(A, e, t) {
        var n;
        for (var r in A)
            if (A[r] in e) return t === !1 ? A[r] : (n = e[A[r]], is(n, "function") ? fnBind(n, t || e) : n);
        return !1
    }

    function testPropsAll(A, e, t, n, r) {
        var i = A.charAt(0).toUpperCase() + A.slice(1),
            o = (A + " " + cssomPrefixes.join(i + " ") + i).split(" ");
        return is(e, "string") || is(e, "undefined") ? testProps(o, e, n, r) : (o = (A + " " + domPrefixes.join(i + " ") + i).split(" "), testDOMProps(o, e, t))
    }

    function testAllProps(A, e, t) {
        return testPropsAll(A, undefined, undefined, e, t)
    }
    var classes = [],
        tests = [],
        ModernizrProto = {
            _version: "3.3.1",
            _config: {
                classPrefix: "",
                enableClasses: !0,
                enableJSClass: !0,
                usePrefixes: !0
            },
            _q: [],
            on: function (A, e) {
                var t = this;
                setTimeout(function () {
                    e(t[A])
                }, 0)
            },
            addTest: function (A, e, t) {
                tests.push({
                    name: A,
                    fn: e,
                    options: t
                })
            },
            addAsyncTest: function (A) {
                tests.push({
                    name: null,
                    fn: A
                })
            }
        },
        Modernizr = function () {};
    Modernizr.prototype = ModernizrProto, Modernizr = new Modernizr, Modernizr.addTest("applicationcache", "applicationCache" in window), Modernizr.addTest("blobconstructor", function () {
        try {
            return !!new Blob
        } catch (A) {
            return !1
        }
    }, {
        aliases: ["blob-constructor"]
    }), Modernizr.addTest("cookies", function () {
        try {
            document.cookie = "cookietest=1";
            var A = -1 != document.cookie.indexOf("cookietest=");
            return document.cookie = "cookietest=1; expires=Thu, 01-Jan-1970 00:00:01 GMT", A
        } catch (e) {
            return !1
        }
    }), Modernizr.addTest("cors", "XMLHttpRequest" in window && "withCredentials" in new XMLHttpRequest), Modernizr.addTest("customprotocolhandler", function () {
        if (!navigator.registerProtocolHandler) return !1;
        try {
            navigator.registerProtocolHandler("thisShouldFail")
        } catch (A) {
            return A instanceof TypeError
        }
        return !1
    }), Modernizr.addTest("customevent", "CustomEvent" in window && "function" == typeof window.CustomEvent), Modernizr.addTest("dataview", "undefined" != typeof DataView && "getFloat64" in DataView.prototype), Modernizr.addTest("eventlistener", "addEventListener" in window), Modernizr.addTest("geolocation", "geolocation" in navigator), Modernizr.addTest("history", function () {
        var A = navigator.userAgent;
        return -1 === A.indexOf("Android 2.") && -1 === A.indexOf("Android 4.0") || -1 === A.indexOf("Mobile Safari") || -1 !== A.indexOf("Chrome") || -1 !== A.indexOf("Windows Phone") ? window.history && "pushState" in window.history : !1
    }), Modernizr.addTest("ie8compat", !window.addEventListener && !!document.documentMode && 7 === document.documentMode), Modernizr.addTest("json", "JSON" in window && "parse" in JSON && "stringify" in JSON), Modernizr.addTest("notification", function () {
        if (!window.Notification || !window.Notification.requestPermission) return !1;
        if ("granted" === window.Notification.permission) return !0;
        try {
            new window.Notification("")
        } catch (A) {
            if ("TypeError" === A.name) return !1
        }
        return !0
    }), Modernizr.addTest("postmessage", "postMessage" in window), Modernizr.addTest("queryselector", "querySelector" in document && "querySelectorAll" in document), Modernizr.addTest("serviceworker", "serviceWorker" in navigator), Modernizr.addTest("svg", !!document.createElementNS && !!document.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect), Modernizr.addTest("templatestrings", function () {
        var supports;
        try {
            eval("``"), supports = !0
        } catch (e) {}
        return !!supports
    }), Modernizr.addTest("typedarrays", "ArrayBuffer" in window);
    var supports = !1;
    try {
        supports = "WebSocket" in window && 2 === window.WebSocket.CLOSING
    } catch (e) {}
    Modernizr.addTest("websockets", supports), Modernizr.addTest("xdomainrequest", "XDomainRequest" in window), Modernizr.addTest("webaudio", function () {
        var A = "webkitAudioContext" in window,
            e = "AudioContext" in window;
        return Modernizr._config.usePrefixes ? A || e : e
    });
    var CSS = window.CSS;
    Modernizr.addTest("cssescape", CSS ? "function" == typeof CSS.escape : !1);
    var newSyntax = "CSS" in window && "supports" in window.CSS,
        oldSyntax = "supportsCSS" in window;
    Modernizr.addTest("supports", newSyntax || oldSyntax), Modernizr.addTest("target", function () {
        var A = window.document;
        if (!("querySelectorAll" in A)) return !1;
        try {
            return A.querySelectorAll(":target"), !0
        } catch (e) {
            return !1
        }
    }), Modernizr.addTest("microdata", "getItems" in document), Modernizr.addTest("mutationobserver", !!window.MutationObserver || !!window.WebKitMutationObserver), Modernizr.addTest("picture", "HTMLPictureElement" in window), Modernizr.addTest("es5array", function () {
        return !!(Array.prototype && Array.prototype.every && Array.prototype.filter && Array.prototype.forEach && Array.prototype.indexOf && Array.prototype.lastIndexOf && Array.prototype.map && Array.prototype.some && Array.prototype.reduce && Array.prototype.reduceRight && Array.isArray)
    }), Modernizr.addTest("es5date", function () {
        var A = "2013-04-12T06:06:37.307Z",
            e = !1;
        try {
            e = !!Date.parse(A)
        } catch (t) {}
        return !!(Date.now && Date.prototype && Date.prototype.toISOString && Date.prototype.toJSON && e)
    }), Modernizr.addTest("es5function", function () {
        return !(!Function.prototype || !Function.prototype.bind)
    }), Modernizr.addTest("es5object", function () {
        return !!(Object.keys && Object.create && Object.getPrototypeOf && Object.getOwnPropertyNames && Object.isSealed && Object.isFrozen && Object.isExtensible && Object.getOwnPropertyDescriptor && Object.defineProperty && Object.defineProperties && Object.seal && Object.freeze && Object.preventExtensions)
    }), Modernizr.addTest("strictmode", function () {
        "use strict";
        return !this
    }()), Modernizr.addTest("es5string", function () {
        return !(!String.prototype || !String.prototype.trim)
    }), Modernizr.addTest("es5syntax", function () {
        var value, obj, stringAccess, getter, setter, reservedWords, zeroWidthChars;
        try {
            return stringAccess = eval('"foobar"[3] === "b"'), getter = eval("({ get x(){ return 1 } }).x === 1"), eval("({ set x(v){ value = v; } }).x = 1"), setter = 1 === value, eval("obj = ({ if: 1 })"), reservedWords = 1 === obj["if"], zeroWidthChars = eval("_‌‍ = true"), stringAccess && getter && setter && reservedWords && zeroWidthChars
        } catch (ignore) {
            return !1
        }
    }), Modernizr.addTest("es5undefined", function () {
        var A, e;
        try {
            e = window.undefined, window.undefined = 12345, A = "undefined" == typeof window.undefined, window.undefined = e
        } catch (t) {
            return !1
        }
        return A
    }), Modernizr.addTest("es5", function () {
        return !!(Modernizr.es5array && Modernizr.es5date && Modernizr.es5function && Modernizr.es5object && Modernizr.strictmode && Modernizr.es5string && Modernizr.json && Modernizr.es5syntax && Modernizr.es5undefined)
    }), Modernizr.addTest("es6array", !!(Array.prototype && Array.prototype.copyWithin && Array.prototype.fill && Array.prototype.find && Array.prototype.findIndex && Array.prototype.keys && Array.prototype.entries && Array.prototype.values && Array.from && Array.of)), Modernizr.addTest("es6collections", !!(window.Map && window.Set && window.WeakMap && window.WeakSet)), Modernizr.addTest("generators", function () {
        try {
            new Function("function* test() {}")()
        } catch (A) {
            return !1
        }
        return !0
    }), Modernizr.addTest("es6math", !!(Math && Math.clz32 && Math.cbrt && Math.imul && Math.sign && Math.log10 && Math.log2 && Math.log1p && Math.expm1 && Math.cosh && Math.sinh && Math.tanh && Math.acosh && Math.asinh && Math.atanh && Math.hypot && Math.trunc && Math.fround)), Modernizr.addTest("es6number", !!(Number.isFinite && Number.isInteger && Number.isSafeInteger && Number.isNaN && Number.parseInt && Number.parseFloat && Number.isInteger(Number.MAX_SAFE_INTEGER) && Number.isInteger(Number.MIN_SAFE_INTEGER) && Number.isFinite(Number.EPSILON))), Modernizr.addTest("es6object", !!(Object.assign && Object.is && Object.setPrototypeOf)), Modernizr.addTest("promises", function () {
        return "Promise" in window && "resolve" in window.Promise && "reject" in window.Promise && "all" in window.Promise && "race" in window.Promise && function () {
            var A;
            return new window.Promise(function (e) {
                A = e
            }), "function" == typeof A
        }()
    }), Modernizr.addTest("es6string", !!(String.fromCodePoint && String.raw && String.prototype.codePointAt && String.prototype.repeat && String.prototype.startsWith && String.prototype.endsWith && String.prototype.contains)), Modernizr.addTest("devicemotion", "DeviceMotionEvent" in window), Modernizr.addTest("deviceorientation", "DeviceOrientationEvent" in window), Modernizr.addTest("filereader", !!(window.File && window.FileList && window.FileReader)), Modernizr.addTest("beacon", "sendBeacon" in navigator), Modernizr.addTest("lowbandwidth", function () {
        var A = navigator.connection || {
            type: 0
        };
        return 3 == A.type || 4 == A.type || /^[23]g$/.test(A.type)
    }), Modernizr.addTest("eventsource", "EventSource" in window), Modernizr.addTest("fetch", "fetch" in window), Modernizr.addTest("xhrresponsetype", function () {
        if ("undefined" == typeof XMLHttpRequest) return !1;
        var A = new XMLHttpRequest;
        return A.open("get", "/", !0), "response" in A
    }()), Modernizr.addTest("xhr2", "XMLHttpRequest" in window && "withCredentials" in new XMLHttpRequest), Modernizr.addTest("speechsynthesis", "SpeechSynthesisUtterance" in window), Modernizr.addTest("localstorage", function () {
        var A = "modernizr";
        try {
            return localStorage.setItem(A, A), localStorage.removeItem(A), !0
        } catch (e) {
            return !1
        }
    }), Modernizr.addTest("sessionstorage", function () {
        var A = "modernizr";
        try {
            return sessionStorage.setItem(A, A), sessionStorage.removeItem(A), !0
        } catch (e) {
            return !1
        }
    }), Modernizr.addTest("websqldatabase", "openDatabase" in window), Modernizr.addTest("svgfilters", function () {
        var A = !1;
        try {
            A = "SVGFEColorMatrixElement" in window && 2 == SVGFEColorMatrixElement.SVG_FECOLORMATRIX_TYPE_SATURATE
        } catch (e) {}
        return A
    }), Modernizr.addTest("urlparser", function () {
        var A;
        try {
            return A = new URL("http://modernizr.com/"), "http://modernizr.com/" === A.href
        } catch (e) {
            return !1
        }
    }), Modernizr.addTest("websocketsbinary", function () {
        var A, e = "https:" == location.protocol ? "wss" : "ws";
        if ("WebSocket" in window) {
            if (A = "binaryType" in WebSocket.prototype) return A;
            try {
                return !!new WebSocket(e + "://.").binaryType
            } catch (t) {}
        }
        return !1
    }), Modernizr.addTest("atobbtoa", "atob" in window && "btoa" in window, {
        aliases: ["atob-btoa"]
    }), Modernizr.addTest("framed", window.location != top.location), Modernizr.addTest("sharedworkers", "SharedWorker" in window), Modernizr.addTest("webworkers", "Worker" in window);
    var prefixes = ModernizrProto._config.usePrefixes ? " -webkit- -moz- -o- -ms- ".split(" ") : ["", ""];
    ModernizrProto._prefixes = prefixes, Modernizr.addTest("contains", is(String.prototype.contains, "function"));
    var docElement = document.documentElement;
    Modernizr.addTest("contextmenu", "contextMenu" in docElement && "HTMLMenuItemElement" in window), Modernizr.addTest("cssall", "all" in docElement.style), Modernizr.addTest("willchange", "willChange" in docElement.style), Modernizr.addTest("classlist", "classList" in docElement), Modernizr.addTest("documentfragment", function () {
        return "createDocumentFragment" in document && "appendChild" in docElement
    });
    var isSVG = "svg" === docElement.nodeName.toLowerCase(),
        html5;
    isSVG || ! function (A, e) {
        function t(A, e) {
            var t = A.createElement("p"),
                n = A.getElementsByTagName("head")[0] || A.documentElement;
            return t.innerHTML = "x<style>" + e + "</style>", n.insertBefore(t.lastChild, n.firstChild)
        }

        function n() {
            var A = h.elements;
            return "string" == typeof A ? A.split(" ") : A
        }

        function r(A, e) {
            var t = h.elements;
            "string" != typeof t && (t = t.join(" ")), "string" != typeof A && (A = A.join(" ")), h.elements = t + " " + A, s(e)
        }

        function i(A) {
            var e = E[A[f]];
            return e || (e = {}, g++, A[f] = g, E[g] = e), e
        }

        function o(A, t, n) {
            if (t || (t = e), c) return t.createElement(A);
            n || (n = i(t));
            var r;
            return r = n.cache[A] ? n.cache[A].cloneNode() : m.test(A) ? (n.cache[A] = n.createElem(A)).cloneNode() : n.createElem(A), !r.canHaveChildren || w.test(A) || r.tagUrn ? r : n.frag.appendChild(r)
        }

        function d(A, t) {
            if (A || (A = e), c) return A.createDocumentFragment();
            t = t || i(A);
            for (var r = t.frag.cloneNode(), o = 0, d = n(), a = d.length; a > o; o++) r.createElement(d[o]);
            return r
        }

        function a(A, e) {
            e.cache || (e.cache = {}, e.createElem = A.createElement, e.createFrag = A.createDocumentFragment, e.frag = e.createFrag()), A.createElement = function (t) {
                return h.shivMethods ? o(t, A, e) : e.createElem(t)
            }, A.createDocumentFragment = Function("h,f", "return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&(" + n().join().replace(/[\w\-:]+/g, function (A) {
                return e.createElem(A), e.frag.createElement(A), 'c("' + A + '")'
            }) + ");return n}")(h, e.frag)
        }

        function s(A) {
            A || (A = e);
            var n = i(A);
            return !h.shivCSS || l || n.hasCSS || (n.hasCSS = !!t(A, "article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")), c || a(A, n), A
        }
        var l, c, u = "3.7.3",
            p = A.html5 || {},
            w = /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,
            m = /^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,
            f = "_html5shiv",
            g = 0,
            E = {};
        ! function () {
            try {
                var A = e.createElement("a");
                A.innerHTML = "<xyz></xyz>", l = "hidden" in A, c = 1 == A.childNodes.length || function () {
                    e.createElement("a");
                    var A = e.createDocumentFragment();
                    return "undefined" == typeof A.cloneNode || "undefined" == typeof A.createDocumentFragment || "undefined" == typeof A.createElement
                }()
            } catch (t) {
                l = !0, c = !0
            }
        }();
        var h = {
            elements: p.elements || "abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output picture progress section summary template time video",
            version: u,
            shivCSS: p.shivCSS !== !1,
            supportsUnknownElements: c,
            shivMethods: p.shivMethods !== !1,
            type: "default",
            shivDocument: s,
            createElement: o,
            createDocumentFragment: d,
            addElements: r
        };
        A.html5 = h, s(e), "object" == typeof module && module.exports && (module.exports = h)
    }("undefined" != typeof window ? window : this, document);
    var omPrefixes = "Moz O ms Webkit",
        domPrefixes = ModernizrProto._config.usePrefixes ? omPrefixes.toLowerCase().split(" ") : [];
    ModernizrProto._domPrefixes = domPrefixes;
    var hasOwnProp;
    ! function () {
        var A = {}.hasOwnProperty;
        hasOwnProp = is(A, "undefined") || is(A.call, "undefined") ? function (A, e) {
            return e in A && is(A.constructor.prototype[e], "undefined")
        } : function (e, t) {
            return A.call(e, t)
        }
    }(), ModernizrProto._l = {}, ModernizrProto.on = function (A, e) {
        this._l[A] || (this._l[A] = []), this._l[A].push(e), Modernizr.hasOwnProperty(A) && setTimeout(function () {
            Modernizr._trigger(A, Modernizr[A])
        }, 0)
    }, ModernizrProto._trigger = function (A, e) {
        if (this._l[A]) {
            var t = this._l[A];
            setTimeout(function () {
                var A, n;
                for (A = 0; A < t.length; A++)(n = t[A])(e)
            }, 0), delete this._l[A]
        }
    }, Modernizr._q.push(function () {
        ModernizrProto.addTest = addTest
    }), Modernizr.addAsyncTest(function () {
        var A = new Image;
        A.onerror = function () {
            addTest("exiforientation", !1, {
                aliases: ["exif-orientation"]
            })
        }, A.onload = function () {
            addTest("exiforientation", 2 !== A.width, {
                aliases: ["exif-orientation"]
            })
        }, A.src = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QAiRXhpZgAASUkqAAgAAAABABIBAwABAAAABgASAAAAAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAABAAIDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD+/iiiigD/2Q=="
    }), Modernizr.addAsyncTest(function () {
        function A() {
            clearTimeout(e), window.removeEventListener("deviceproximity", A), addTest("proximity", !0)
        }
        var e, t = 300;
        "ondeviceproximity" in window && "onuserproximity" in window ? (window.addEventListener("deviceproximity", A), e = setTimeout(function () {
            window.removeEventListener("deviceproximity", A), addTest("proximity", !1)
        }, t)) : addTest("proximity", !1)
    }), Modernizr.addAsyncTest(function () {
        var A = new Image;
        A.onload = A.onerror = function () {
            addTest("jpeg2000", 1 == A.width)
        }, A.src = "data:image/jp2;base64,/0//UQAyAAAAAAABAAAAAgAAAAAAAAAAAAAABAAAAAQAAAAAAAAAAAAEBwEBBwEBBwEBBwEB/1IADAAAAAEAAAQEAAH/XAAEQED/ZAAlAAFDcmVhdGVkIGJ5IE9wZW5KUEVHIHZlcnNpb24gMi4wLjD/kAAKAAAAAABYAAH/UwAJAQAABAQAAf9dAAUBQED/UwAJAgAABAQAAf9dAAUCQED/UwAJAwAABAQAAf9dAAUDQED/k8+kEAGvz6QQAa/PpBABr994EAk//9k="
    }), Modernizr.addAsyncTest(function () {
        var A = new Image;
        A.onload = A.onerror = function () {
            addTest("jpegxr", 1 == A.width, {
                aliases: ["jpeg-xr"]
            })
        }, A.src = "data:image/vnd.ms-photo;base64,SUm8AQgAAAAFAAG8AQAQAAAASgAAAIC8BAABAAAAAQAAAIG8BAABAAAAAQAAAMC8BAABAAAAWgAAAMG8BAABAAAAHwAAAAAAAAAkw91vA07+S7GFPXd2jckNV01QSE9UTwAZAYBxAAAAABP/gAAEb/8AAQAAAQAAAA=="
    }), Modernizr.addAsyncTest(function () {
        var A = new Image;
        A.onerror = function () {
            addTest("webpalpha", !1, {
                aliases: ["webp-alpha"]
            })
        }, A.onload = function () {
            addTest("webpalpha", 1 == A.width, {
                aliases: ["webp-alpha"]
            })
        }, A.src = "data:image/webp;base64,UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAABBxAR/Q9ERP8DAABWUDggGAAAADABAJ0BKgEAAQADADQlpAADcAD++/1QAA=="
    }), Modernizr.addAsyncTest(function () {
        var A = new Image;
        A.onerror = function () {
            addTest("webpanimation", !1, {
                aliases: ["webp-animation"]
            })
        }, A.onload = function () {
            addTest("webpanimation", 1 == A.width, {
                aliases: ["webp-animation"]
            })
        }, A.src = "data:image/webp;base64,UklGRlIAAABXRUJQVlA4WAoAAAASAAAAAAAAAAAAQU5JTQYAAAD/////AABBTk1GJgAAAAAAAAAAAAAAAAAAAGQAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcA"
    }), Modernizr.addAsyncTest(function () {
        var A = new Image;
        A.onerror = function () {
            addTest("webplossless", !1, {
                aliases: ["webp-lossless"]
            })
        }, A.onload = function () {
            addTest("webplossless", 1 == A.width, {
                aliases: ["webp-lossless"]
            })
        }, A.src = "data:image/webp;base64,UklGRh4AAABXRUJQVlA4TBEAAAAvAAAAAAfQ//73v/+BiOh/AAA="
    }), Modernizr.addAsyncTest(function () {
        function A(A, e, t) {
            function n(e) {
                var n = e && "load" === e.type ? 1 == r.width : !1,
                    i = "webp" === A;
                addTest(A, i ? new Boolean(n) : n), t && t(e)
            }
            var r = new Image;
            r.onerror = n, r.onload = n, r.src = e
        }
        var e = [{
                uri: "data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA=",
                name: "webp"
            }, {
                uri: "data:image/webp;base64,UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAABBxAR/Q9ERP8DAABWUDggGAAAADABAJ0BKgEAAQADADQlpAADcAD++/1QAA==",
                name: "webp.alpha"
            }, {
                uri: "data:image/webp;base64,UklGRlIAAABXRUJQVlA4WAoAAAASAAAAAAAAAAAAQU5JTQYAAAD/////AABBTk1GJgAAAAAAAAAAAAAAAAAAAGQAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcA",
                name: "webp.animation"
            }, {
                uri: "data:image/webp;base64,UklGRh4AAABXRUJQVlA4TBEAAAAvAAAAAAfQ//73v/+BiOh/AAA=",
                name: "webp.lossless"
            }],
            t = e.shift();
        A(t.name, t.uri, function (t) {
            if (t && "load" === t.type)
                for (var n = 0; n < e.length; n++) A(e[n].name, e[n].uri)
        })
    }), Modernizr.addTest("svgasimg", document.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#Image", "1.1")), Modernizr.addAsyncTest(function () {
        function A() {
            var A = new Image;
            A.onerror = function () {
                addTest("datauri", !0), Modernizr.datauri = new Boolean(!0), Modernizr.datauri.over32kb = !1
            }, A.onload = function () {
                addTest("datauri", !0), Modernizr.datauri = new Boolean(!0), Modernizr.datauri.over32kb = 1 == A.width && 1 == A.height
            };
            for (var e = "R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=="; e.length < 33e3;) e = "\r\n" + e;
            A.src = "data:image/gif;base64," + e
        } - 1 !== navigator.userAgent.indexOf("MSIE 7.") && setTimeout(function () {
            addTest("datauri", !1)
        }, 10);
        var e = new Image;
        e.onerror = function () {
            addTest("datauri", !1)
        }, e.onload = function () {
            1 == e.width && 1 == e.height ? A() : addTest("datauri", !1)
        }, e.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=="
    }), Modernizr.addAsyncTest(function () {
        function A() {
            addTest("blobworkers", !1), e()
        }

        function e() {
            d && n.revokeObjectURL(d), o && o.terminate(), a && clearTimeout(a)
        }
        try {
            var t = window.BlobBuilder,
                n = window.URL;
            Modernizr._config.usePrefix && (t = t || window.MozBlobBuilder || window.WebKitBlobBuilder || window.MSBlobBuilder || window.OBlobBuilder, n = n || window.MozURL || window.webkitURL || window.MSURL || window.OURL);
            var r, i, o, d, a, s = "Modernizr",
                l = "this.onmessage=function(e){postMessage(e.data)}";
            try {
                r = new Blob([l], {
                    type: "text/javascript"
                })
            } catch (c) {}
            r || (i = new t, i.append(l), r = i.getBlob()), d = n.createObjectURL(r), o = new Worker(d), o.onmessage = function (A) {
                addTest("blobworkers", s === A.data), e()
            }, o.onerror = A, a = setTimeout(A, 200), o.postMessage(s)
        } catch (c) {
            A()
        }
    }), Modernizr.addAsyncTest(function () {
        try {
            var A = "Modernizr",
                e = new Worker("data:text/javascript;base64,dGhpcy5vbm1lc3NhZ2U9ZnVuY3Rpb24oZSl7cG9zdE1lc3NhZ2UoZS5kYXRhKX0=");
            e.onmessage = function (t) {
                e.terminate(), addTest("dataworkers", A === t.data), e = null
            }, e.onerror = function () {
                addTest("dataworkers", !1), e = null
            }, setTimeout(function () {
                addTest("dataworkers", !1)
            }, 200), e.postMessage(A)
        } catch (t) {
            setTimeout(function () {
                addTest("dataworkers", !1)
            }, 0)
        }
    });
    var cssomPrefixes = ModernizrProto._config.usePrefixes ? omPrefixes.split(" ") : [];
    ModernizrProto._cssomPrefixes = cssomPrefixes;
    var atRule = function (A) {
        var e, t = prefixes.length,
            n = window.CSSRule;
        if ("undefined" == typeof n) return undefined;
        if (!A) return !1;
        if (A = A.replace(/^@/, ""), e = A.replace(/-/g, "_").toUpperCase() + "_RULE", e in n) return "@" + A;
        for (var r = 0; t > r; r++) {
            var i = prefixes[r],
                o = i.toUpperCase() + "_" + e;
            if (o in n) return "@-" + i.toLowerCase() + "-" + A
        }
        return !1
    };
    ModernizrProto.atRule = atRule;
    var hasEvent = function () {
        function A(A, t) {
            var n;
            return A ? (t && "string" != typeof t || (t = createElement(t || "div")), A = "on" + A, n = A in t, !n && e && (t.setAttribute || (t = createElement("div")), t.setAttribute(A, ""), n = "function" == typeof t[A], t[A] !== undefined && (t[A] = undefined), t.removeAttribute(A)), n) : !1
        }
        var e = !("onblur" in document.documentElement);
        return A
    }();
    ModernizrProto.hasEvent = hasEvent, Modernizr.addTest("ambientlight", hasEvent("devicelight", window)), Modernizr.addTest("hashchange", function () {
        return hasEvent("hashchange", window) === !1 ? !1 : document.documentMode === undefined || document.documentMode > 7
    }), Modernizr.addTest("inputsearchevent", hasEvent("search")), Modernizr.addTest("pointerevents", function () {
        var A = !1,
            e = domPrefixes.length;
        for (A = Modernizr.hasEvent("pointerdown"); e-- && !A;) hasEvent(domPrefixes[e] + "pointerdown") && (A = !0);
        return A
    });
    var prefixedCSSValue = function (A, e) {
        var t = !1,
            n = createElement("div"),
            r = n.style;
        if (A in r) {
            var i = domPrefixes.length;
            for (r[A] = e, t = r[A]; i-- && !t;) r[A] = "-" + domPrefixes[i] + "-" + e, t = r[A]
        }
        return "" === t && (t = !1), t
    };
    ModernizrProto.prefixedCSSValue = prefixedCSSValue, Modernizr.addTest("audio", function () {
        var A = createElement("audio"),
            e = !1;
        try {
            (e = !!A.canPlayType) && (e = new Boolean(e), e.ogg = A.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ""), e.mp3 = A.canPlayType('audio/mpeg; codecs="mp3"').replace(/^no$/, ""), e.opus = A.canPlayType('audio/ogg; codecs="opus"') || A.canPlayType('audio/webm; codecs="opus"').replace(/^no$/, ""), e.wav = A.canPlayType('audio/wav; codecs="1"').replace(/^no$/, ""), e.m4a = (A.canPlayType("audio/x-m4a;") || A.canPlayType("audio/aac;")).replace(/^no$/, ""))
        } catch (t) {}
        return e
    }), Modernizr.addTest("canvas", function () {
        var A = createElement("canvas");
        return !(!A.getContext || !A.getContext("2d"))
    }), Modernizr.addTest("canvastext", function () {
        return Modernizr.canvas === !1 ? !1 : "function" == typeof createElement("canvas").getContext("2d").fillText
    }), Modernizr.addTest("contenteditable", function () {
        if ("contentEditable" in docElement) {
            var A = createElement("div");
            return A.contentEditable = !0, "true" === A.contentEditable
        }
    }), Modernizr.addTest("emoji", function () {
        if (!Modernizr.canvastext) return !1;
        var A = window.devicePixelRatio || 1,
            e = 12 * A,
            t = createElement("canvas"),
            n = t.getContext("2d");
        return n.fillStyle = "#f00", n.textBaseline = "top", n.font = "32px Arial", n.fillText("🐨", 0, 0), 0 !== n.getImageData(e, e, 1, 1).data[0]
    }), addTest("htmlimports", "import" in createElement("link")), Modernizr.addTest("olreversed", "reversed" in createElement("ol")), Modernizr.addTest("userdata", !!createElement("div").addBehavior), Modernizr.addTest("video", function () {
        var A = createElement("video"),
            e = !1;
        try {
            (e = !!A.canPlayType) && (e = new Boolean(e), e.ogg = A.canPlayType('video/ogg; codecs="theora"').replace(/^no$/, ""), e.h264 = A.canPlayType('video/mp4; codecs="avc1.42E01E"').replace(/^no$/, ""), e.webm = A.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/, ""), e.vp9 = A.canPlayType('video/webm; codecs="vp9"').replace(/^no$/, ""), e.hls = A.canPlayType('application/x-mpegURL; codecs="avc1.42E01E"').replace(/^no$/, ""))
        } catch (t) {}
        return e
    }), Modernizr.addTest("vml", function () {
        var A, e = createElement("div"),
            t = !1;
        return isSVG || (e.innerHTML = '<v:shape id="vml_flag1" adj="1" />', A = e.firstChild, "style" in A && (A.style.behavior = "url(#default#VML)"), t = A ? "object" == typeof A.adj : !0), t
    }), Modernizr.addTest("webanimations", "animate" in createElement("div")), Modernizr.addTest("webgl", function () {
        var A = createElement("canvas"),
            e = "probablySupportsContext" in A ? "probablySupportsContext" : "supportsContext";
        return e in A ? A[e]("webgl") || A[e]("experimental-webgl") : "WebGLRenderingContext" in window
    }), Modernizr.addTest("adownload", !window.externalHost && "download" in createElement("a")), Modernizr.addTest("audioloop", "loop" in createElement("audio")), Modernizr.addAsyncTest(function () {
        function A(t) {
            clearTimeout(e);
            var r = t !== undefined && "loadeddata" === t.type ? !0 : !1;
            n.removeEventListener("loadeddata", A, !1), addTest("audiopreload", r), n.parentNode.removeChild(n)
        }
        var e, t = 300,
            n = createElement("audio"),
            r = n.style;
        if (!(Modernizr.audio && "preload" in n)) return void addTest("audiopreload", !1);
        r.position = "absolute", r.height = 0, r.width = 0;
        try {
            if (Modernizr.audio.mp3) n.src = "data:audio/mpeg;base64,//MUxAAB6AXgAAAAAPP+c6nf//yi/6f3//MUxAMAAAIAAAjEcH//0fTX6C9Lf//0//MUxA4BeAIAAAAAAKX2/6zv//+IlR4f//MUxBMCMAH8AAAAABYWalVMQU1FMy45//MUxBUB0AH0AAAAADkuM1VVVVVVVVVV//MUxBgBUATowAAAAFVVVVVVVVVVVVVV";
            else if (Modernizr.audio.m4a) n.src = "data:audio/x-m4a;base64,AAAAGGZ0eXBNNEEgAAACAGlzb21pc28yAAAACGZyZWUAAAAfbWRhdN4EAABsaWJmYWFjIDEuMjgAAAFoAQBHAAACiG1vb3YAAABsbXZoZAAAAAB8JbCAfCWwgAAAA+gAAAAYAAEAAAEAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAG0dHJhawAAAFx0a2hkAAAAD3wlsIB8JbCAAAAAAQAAAAAAAAAYAAAAAAAAAAAAAAAAAQAAAAABAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAABUG1kaWEAAAAgbWRoZAAAAAB8JbCAfCWwgAAArEQAAAQAVcQAAAAAAC1oZGxyAAAAAAAAAABzb3VuAAAAAAAAAAAAAAAAU291bmRIYW5kbGVyAAAAAPttaW5mAAAAEHNtaGQAAAAAAAAAAAAAACRkaW5mAAAAHGRyZWYAAAAAAAAAAQAAAAx1cmwgAAAAAQAAAL9zdGJsAAAAW3N0c2QAAAAAAAAAAQAAAEttcDRhAAAAAAAAAAEAAAAAAAAAAAACABAAAAAArEQAAAAAACdlc2RzAAAAAAMZAAEABBFAFQAAAAABftAAAAAABQISCAYBAgAAABhzdHRzAAAAAAAAAAEAAAABAAAEAAAAABxzdHNjAAAAAAAAAAEAAAABAAAAAQAAAAEAAAAUc3RzegAAAAAAAAAXAAAAAQAAABRzdGNvAAAAAAAAAAEAAAAoAAAAYHVkdGEAAABYbWV0YQAAAAAAAAAhaGRscgAAAAAAAAAAbWRpcmFwcGwAAAAAAAAAAAAAAAAraWxzdAAAACOpdG9vAAAAG2RhdGEAAAABAAAAAExhdmY1Mi42NC4y";
            else if (Modernizr.audio.ogg) n.src = "data:audio/ogg;base64,T2dnUwACAAAAAAAAAAD/QwAAAAAAAM2LVKsBHgF2b3JiaXMAAAAAAUSsAAAAAAAAgLsAAAAAAAC4AU9nZ1MAAAAAAAAAAAAA/0MAAAEAAADmvOe6Dy3/////////////////MgN2b3JiaXMdAAAAWGlwaC5PcmcgbGliVm9yYmlzIEkgMjAwNzA2MjIAAAAAAQV2b3JiaXMfQkNWAQAAAQAYY1QpRplS0kqJGXOUMUaZYpJKiaWEFkJInXMUU6k515xrrLm1IIQQGlNQKQWZUo5SaRljkCkFmVIQS0kldBI6J51jEFtJwdaYa4tBthyEDZpSTCnElFKKQggZU4wpxZRSSkIHJXQOOuYcU45KKEG4nHOrtZaWY4updJJK5yRkTEJIKYWSSgelU05CSDWW1lIpHXNSUmpB6CCEEEK2IIQNgtCQVQAAAQDAQBAasgoAUAAAEIqhGIoChIasAgAyAAAEoCiO4iiOIzmSY0kWEBqyCgAAAgAQAADAcBRJkRTJsSRL0ixL00RRVX3VNlVV9nVd13Vd13UgNGQVAAABAEBIp5mlGiDCDGQYCA1ZBQAgAAAARijCEANCQ1YBAAABAABiKDmIJrTmfHOOg2Y5aCrF5nRwItXmSW4q5uacc845J5tzxjjnnHOKcmYxaCa05pxzEoNmKWgmtOacc57E5kFrqrTmnHPGOaeDcUYY55xzmrTmQWo21uaccxa0pjlqLsXmnHMi5eZJbS7V5pxzzjnnnHPOOeecc6oXp3NwTjjnnHOi9uZabkIX55xzPhmne3NCOOecc84555xzzjnnnHOC0JBVAAAQAABBGDaGcacgSJ+jgRhFiGnIpAfdo8MkaAxyCqlHo6ORUuoglFTGSSmdIDRkFQAACAAAIYQUUkghhRRSSCGFFFKIIYYYYsgpp5yCCiqppKKKMsoss8wyyyyzzDLrsLPOOuwwxBBDDK20EktNtdVYY62555xrDtJaaa211koppZRSSikIDVkFAIAAABAIGWSQQUYhhRRSiCGmnHLKKaigAkJDVgEAgAAAAgAAADzJc0RHdERHdERHdERHdETHczxHlERJlERJtEzL1ExPFVXVlV1b1mXd9m1hF3bd93Xf93Xj14VhWZZlWZZlWZZlWZZlWZZlWYLQkFUAAAgAAIAQQgghhRRSSCGlGGPMMeegk1BCIDRkFQAACAAgAAAAwFEcxXEkR3IkyZIsSZM0S7M8zdM8TfREURRN01RFV3RF3bRF2ZRN13RN2XRVWbVdWbZt2dZtX5Zt3/d93/d93/d93/d93/d1HQgNWQUASAAA6EiOpEiKpEiO4ziSJAGhIasAABkAAAEAKIqjOI7jSJIkSZakSZ7lWaJmaqZneqqoAqEhqwAAQAAAAQAAAAAAKJriKabiKaLiOaIjSqJlWqKmaq4om7Lruq7ruq7ruq7ruq7ruq7ruq7ruq7ruq7ruq7ruq7ruq7rui4QGrIKAJAAANCRHMmRHEmRFEmRHMkBQkNWAQAyAAACAHAMx5AUybEsS9M8zdM8TfRET/RMTxVd0QVCQ1YBAIAAAAIAAAAAADAkw1IsR3M0SZRUS7VUTbVUSxVVT1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTVN0zRNIDRkJQAABADAYo3B5SAhJSXl3hDCEJOeMSYhtV4hBJGS3jEGFYOeMqIMct5C4xCDHggNWREARAEAAMYgxxBzyDlHqZMSOeeodJQa5xyljlJnKcWYYs0oldhSrI1zjlJHraOUYiwtdpRSjanGAgAAAhwAAAIshEJDVgQAUQAAhDFIKaQUYow5p5xDjCnnmHOGMeYcc44556B0UirnnHROSsQYc445p5xzUjonlXNOSiehAACAAAcAgAALodCQFQFAnACAQZI8T/I0UZQ0TxRFU3RdUTRd1/I81fRMU1U90VRVU1Vt2VRVWZY8zzQ901RVzzRV1VRVWTZVVZZFVdVt03V123RV3ZZt2/ddWxZ2UVVt3VRd2zdV1/Zd2fZ9WdZ1Y/I8VfVM03U903Rl1XVtW3VdXfdMU5ZN15Vl03Vt25VlXXdl2fc103Rd01Vl2XRd2XZlV7ddWfZ903WF35VlX1dlWRh2XfeFW9eV5XRd3VdlVzdWWfZ9W9eF4dZ1YZk8T1U903RdzzRdV3VdX1dd19Y105Rl03Vt2VRdWXZl2fddV9Z1zzRl2XRd2zZdV5ZdWfZ9V5Z13XRdX1dlWfhVV/Z1WdeV4dZt4Tdd1/dVWfaFV5Z14dZ1Ybl1XRg+VfV9U3aF4XRl39eF31luXTiW0XV9YZVt4VhlWTl+4ViW3feVZXRdX1ht2RhWWRaGX/id5fZ943h1XRlu3efMuu8Mx++k+8rT1W1jmX3dWWZfd47hGDq/8OOpqq+brisMpywLv+3rxrP7vrKMruv7qiwLvyrbwrHrvvP8vrAso+z6wmrLwrDatjHcvm4sv3Acy2vryjHrvlG2dXxfeArD83R1XXlmXcf2dXTjRzh+ygAAgAEHAIAAE8pAoSErAoA4AQCPJImiZFmiKFmWKIqm6LqiaLqupGmmqWmeaVqaZ5qmaaqyKZquLGmaaVqeZpqap5mmaJqua5qmrIqmKcumasqyaZqy7LqybbuubNuiacqyaZqybJqmLLuyq9uu7Oq6pFmmqXmeaWqeZ5qmasqyaZquq3meanqeaKqeKKqqaqqqraqqLFueZ5qa6KmmJ4qqaqqmrZqqKsumqtqyaaq2bKqqbbuq7Pqybeu6aaqybaqmLZuqatuu7OqyLNu6L2maaWqeZ5qa55mmaZqybJqqK1uep5qeKKqq5ommaqqqLJumqsqW55mqJ4qq6omea5qqKsumatqqaZq2bKqqLZumKsuubfu+68qybqqqbJuqauumasqybMu+78qq7oqmKcumqtqyaaqyLduy78uyrPuiacqyaaqybaqqLsuybRuzbPu6aJqybaqmLZuqKtuyLfu6LNu678qub6uqrOuyLfu67vqucOu6MLyybPuqrPq6K9u6b+sy2/Z9RNOUZVM1bdtUVVl2Zdn2Zdv2fdE0bVtVVVs2TdW2ZVn2fVm2bWE0Tdk2VVXWTdW0bVmWbWG2ZeF2Zdm3ZVv2ddeVdV/XfePXZd3murLty7Kt+6qr+rbu+8Jw667wCgAAGHAAAAgwoQwUGrISAIgCAACMYYwxCI1SzjkHoVHKOecgZM5BCCGVzDkIIZSSOQehlJQy5yCUklIIoZSUWgshlJRSawUAABQ4AAAE2KApsThAoSErAYBUAACD41iW55miatqyY0meJ4qqqaq27UiW54miaaqqbVueJ4qmqaqu6+ua54miaaqq6+q6aJqmqaqu67q6Lpqiqaqq67qyrpumqqquK7uy7Oumqqqq68quLPvCqrquK8uybevCsKqu68qybNu2b9y6ruu+7/vCka3rui78wjEMRwEA4AkOAEAFNqyOcFI0FlhoyEoAIAMAgDAGIYMQQgYhhJBSSiGllBIAADDgAAAQYEIZKDRkRQAQJwAAGEMppJRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkgppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkqppJRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoplVJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSCgCQinAAkHowoQwUGrISAEgFAACMUUopxpyDEDHmGGPQSSgpYsw5xhyUklLlHIQQUmktt8o5CCGk1FJtmXNSWosx5hgz56SkFFvNOYdSUoux5ppr7qS0VmuuNedaWqs115xzzbm0FmuuOdecc8sx15xzzjnnGHPOOeecc84FAOA0OACAHtiwOsJJ0VhgoSErAYBUAAACGaUYc8456BBSjDnnHIQQIoUYc845CCFUjDnnHHQQQqgYc8w5CCGEkDnnHIQQQgghcw466CCEEEIHHYQQQgihlM5BCCGEEEooIYQQQgghhBA6CCGEEEIIIYQQQgghhFJKCCGEEEIJoZRQAABggQMAQIANqyOcFI0FFhqyEgAAAgCAHJagUs6EQY5Bjw1BylEzDUJMOdGZYk5qMxVTkDkQnXQSGWpB2V4yCwAAgCAAIMAEEBggKPhCCIgxAABBiMwQCYVVsMCgDBoc5gHAA0SERACQmKBIu7iALgNc0MVdB0IIQhCCWBxAAQk4OOGGJ97whBucoFNU6iAAAAAAAAwA4AEA4KAAIiKaq7C4wMjQ2ODo8AgAAAAAABYA+AAAOD6AiIjmKiwuMDI0Njg6PAIAAAAAAAAAAICAgAAAAAAAQAAAAICAT2dnUwAE7AwAAAAAAAD/QwAAAgAAADuydfsFAQEBAQEACg4ODg==";
            else {
                if (!Modernizr.audio.wav) return void addTest("audiopreload", !1);
                n.src = "data:audio/wav;base64,UklGRvwZAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YdgZAAAAAAEA/v8CAP//AAABAP////8DAPz/BAD9/wEAAAAAAAAAAAABAP7/AgD//wAAAQD//wAAAQD//wAAAQD+/wIA//8AAAAAAAD//wIA/v8BAAAA//8BAAAA//8BAP//AQAAAP//AQD//wEAAAD//wEA//8BAP//AQD//wEA//8BAP//AQD+/wMA/f8DAP3/AgD+/wIA/////wMA/f8CAP7/AgD+/wMA/f8CAP7/AgD//wAAAAAAAAAAAQD+/wIA/v8CAP7/AwD9/wIA/v8BAAEA/v8CAP7/AQAAAAAAAAD//wEAAAD//wIA/f8DAP7/AQD//wEAAAD//wEA//8CAP7/AQD//wIA/v8CAP7/AQAAAAAAAAD//wEAAAAAAAAA//8BAP//AgD9/wQA+/8FAPz/AgAAAP//AgD+/wEAAAD//wIA/v8CAP3/BAD8/wQA/P8DAP7/AwD8/wQA/P8DAP7/AQAAAAAA//8BAP//AgD+/wEAAAD//wIA/v8BAP//AQD//wEAAAD//wEA//8BAAAAAAAAAP//AgD+/wEAAAAAAAAAAAD//wEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//AgD+/wIA/v8BAP//AQABAP7/AQD//wIA/v8CAP3/AwD/////AgD9/wMA/v8BAP//AQAAAP//AQD//wEA//8BAP//AAABAP//AAABAP//AQD//wAAAAACAP3/AwD9/wIA//8BAP//AQD//wEA//8BAP//AgD9/wMA/v8AAAIA/f8CAAAA/v8EAPv/BAD9/wIAAAD+/wQA+v8HAPr/BAD+/wEAAAD//wIA/f8EAPz/BAD7/wUA/P8EAPz/AwD+/wEAAAD//wEAAAAAAP//AgD8/wUA+/8FAPz/AwD9/wIA//8AAAEA/v8CAP//AQD//wAAAAABAP//AgD9/wMA/f8EAPz/AwD+/wAAAwD7/wUA/P8DAP7/AQAAAP//AgD+/wEAAQD+/wIA/v8BAAEA/v8CAP7/AQAAAP//AgD9/wMA/f8DAP7/AgD+/wEAAAAAAAEA//8AAAEA/v8DAP3/AgD//wEA//8BAP7/AwD9/wMA/v8BAP//AQAAAP//AgD9/wMA/v8BAP//AQAAAP//AgD+/wEAAQD+/wIA/////wIA//8AAAEA/f8DAP//AAABAP////8DAP3/AwD+/wEA//8BAP//AQAAAAAA//8BAP//AQD//wEA//8BAP//AAAAAAEA//8BAP7/AgD//wEA//8AAAAAAAAAAAAAAAD//wIA/v8BAAAA//8BAAEA/v8BAAAA//8DAPz/AwD+/wIA/v8CAP3/AwD+/wEAAAD//wEA//8BAAAA//8BAAAA/v8EAPv/BAD+/wAAAAABAP7/AgD//wAAAAABAP7/AgD//wAAAAAAAAAAAAABAP3/BAD8/wQA/f8BAAAAAAABAP7/AgD+/wIA/v8CAP7/AgD+/wIA/v8BAAAAAAD//wIA/f8DAP7/AAABAP//AAACAPz/BAD9/wIA//8AAP//AwD9/wMA/P8EAP3/AwD9/wIA//8BAP//AQD+/wMA/f8DAP7/AAABAP//AQAAAP//AQD//wIA/f8DAP7/AQAAAP//AQAAAAAA//8CAP7/AQABAP7/AgD+/wEAAQD+/wIA/v8CAP////8CAP7/AgD//wAAAAABAP7/AwD9/wIAAAD+/wMA/f8CAP//AQD+/wMA/f8CAP//AAACAPz/BQD6/wUA/v///wIA/v8CAP3/BAD7/wYA+v8FAPz/AwD/////AgD+/wEAAAD//wEAAAD//wIA/f8DAP7/AQAAAP//AgD//wAA//8BAAAAAAAAAP//AQD//wEA//8AAAIA/f8DAP3/AgAAAP//AQD//wEA//8AAAEA//8BAP////8CAP//AAABAP3/BAD9/wIA/v8BAAEA//8BAP7/AgD//wEA//8AAAEA//8BAP//AAAAAAEA//8BAP7/AgD//wEA//8AAAAAAQD+/wIA/v8BAAAAAAD//wIA/v8BAAAAAAAAAAAAAQD+/wMA/f8CAP//AQD//wIA/f8DAP7/AQD//wEA//8CAP7/AAABAP7/AwD9/wMA/v8AAAEA//8BAAAAAAD//wIA/v8BAAAA//8CAP7/AgD+/wEA//8CAP7/AgD//wAAAAAAAAAAAQD//wEA/v8DAPz/BQD8/wIA//8AAAEAAAD//wEA//8BAP//AQAAAAAA//8BAP//AgD+/wEAAAAAAP//AQD+/wMA/////wEA/v8CAP//AQD//wEA//8AAAEA//8BAAAA/v8EAPz/AwD+/wEAAAAAAAAA//8CAP7/AQD//wEA//8BAP//AAABAP7/AwD9/wIA//8BAP//AQD//wEA//8AAAEA/v8EAPv/BAD9/wIA//8BAP7/AwD9/wIA//8AAAEA//8BAP//AQD//wAAAQD//wEAAAD+/wMA/v8AAAIA/f8DAP7/AQD//wAAAQD+/wMA/f8CAP//AAABAP7/AgD+/wMA/f8CAP7/AQABAP7/AgD+/wIA/v8CAP7/AwD8/wMA//8AAAEA//8AAAAAAAABAP//AQD//wAAAQD//wIA/f8DAP3/AwD+/wAAAgD9/wIA//8AAAEAAAD+/wMA/P8FAPv/BAD9/wIA//8AAP//AgD+/wIA/v8BAAAAAAD//wEAAAAAAP//AQD//wEA//8BAP//AAABAP7/AwD9/wIA//8BAP//AAABAP//AQD//wAAAQD//wEA//8BAP//AAABAAAA//8BAP7/AwD9/wMA/f8DAP3/AgD//wEA//8BAP7/AgD//wAAAgD8/wQA/f8CAP//AQD+/wMA/f8CAP7/AgD//wAAAAAAAAAAAAABAP7/AwD9/wIA/v8DAP3/AwD9/wIA/v8DAPz/BQD7/wQA/f8CAP7/AwD9/wMA/f8CAP//AQAAAP7/AwD+/wEA//8AAAEAAAAAAP//AAABAP//AQAAAP7/AwD9/wMA/f8CAP//AQD//wEA//8AAAIA/f8CAAAA//8BAAAA//8BAAAA/v8EAPv/BAD9/wIA//8AAAEA/v8CAP//AAABAP//AAABAP//AAABAP7/AwD8/wQA/f8CAAAA/v8DAP3/AwD9/wMA/v8BAAAA//8BAAAA//8CAP7/AQAAAAAAAAAAAAAA//8CAP7/AgD+/wIA/v8CAP7/AgD//wAAAQD//wAAAQD//wAAAQD//wAAAQD+/wIA//8AAAAAAQD+/wMA/f8CAP//AQD//wEA//8AAAEA/v8DAP3/AgD//wAAAAABAP7/AwD9/wIA//8AAAEA/v8DAP3/AgD//wAAAAABAP7/AwD8/wMA/v8CAP//AAD//wIA/v8CAP7/AQABAP7/AQAAAP//AgD/////AQD//wEAAAD//wEA/v8EAPv/BAD9/wMA/v8BAAAA//8BAAEA/P8GAPr/BQD8/wMA/v8BAAAA//8CAP7/AQABAP3/BAD7/wYA+/8EAPz/AwD//wEA//8BAP7/BAD8/wMA/v8AAAIA/v8BAAAA//8BAAAA//8BAAAA//8CAP3/AwD+/wAAAgD8/wUA/P8DAP7/AAABAAAAAAD//wEAAAD//wIA/f8DAP7/AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAEA/f8EAPz/AwD/////AgD+/wIA/f8DAP7/AgD+/wEA//8CAP7/AQD//wEAAAAAAP//AQAAAP//AgD9/wMA/v8BAAAA//8BAP//AQAAAP//AAACAP3/BAD7/wQA/v8BAAAA//8BAP//AQAAAP//AQAAAP7/BAD7/wUA+/8EAP3/AgD//wAAAQD+/wIA//8AAAEA/v8CAP//AQD+/wEAAAAAAAAAAAD//wEA//8CAP3/AwD9/wIA//8AAAAAAAAAAAAA//8BAP//AgD+/wEA//8CAP7/AQAAAP//AgD/////AgD/////AgD+/wIA//8AAP//AQABAP7/AgD9/wMA/v8CAP////8BAAAAAAAAAAAA//8CAP////8DAPz/AwD+/wEAAAAAAP//AQD//wEAAAD//wEAAAD+/wQA+/8FAPz/AgAAAP//AgD9/wMA/v8BAAAAAAD//wEAAAD//wIA/v8BAAAAAAD//wIA/v8BAAAA//8BAAAA//8CAP7/AQD//wEA//8BAAAA//8BAP//AAABAP//AQAAAP7/AgD//wEA//8AAAAAAQD+/wMA/P8EAP7///8DAPz/BQD8/wEAAQD+/wMA/v8AAAEA//8BAP//AQD//wEA/v8CAP//AQD//wAAAAABAAAA//8BAP//AQAAAAAA//8BAP//AgD+/wAAAQD//wIA/f8CAP//AQAAAP7/AwD9/wMA/v8BAP//AAABAP//AgD9/wIA//8BAAAA//8BAAAA//8CAP3/AwD+/wEAAAD+/wQA/P8DAP7/AAACAP7/AQAAAP//AQAAAP//AQAAAP//AgD9/wIAAAD//wIA/f8DAP7/AQD//wEA//8CAP7/AQD//wAAAQD//wEA//8AAAAAAQD//wEAAAD9/wUA+/8FAPz/AgD//wAAAQD//wAAAQD+/wMA/f8BAAEA/v8CAP7/AgD+/wIA/v8BAAAAAAAAAAAAAAD//wIA/v8CAP////8CAP7/AgD+/wIA/v8CAP7/AQAAAP//AQAAAP//AQD//wAAAQD//wAAAQD+/wMA/f8CAAAA/v8DAP3/AgAAAP//AQAAAP7/AwD9/wMA/v8BAP//AQD//wEAAAD+/wMA/f8CAAAA/v8CAP//AAAAAAEA//8AAAEA/v8DAP3/AwD9/wIA//8BAP//AgD8/wQA/v8BAAAA/v8CAP//AQD//wAAAAAAAAEA/f8EAPz/BAD9/wIA//8AAAAAAAABAP//AAAAAAAAAAABAP3/BAD9/wIA/v8BAAEA//8AAAAA//8CAP7/AgD9/wQA+/8FAPv/BQD8/wMA/f8DAP3/AwD+/wAAAgD9/wMA/f8CAAAA/v8EAPv/BQD7/wUA/P8DAP///v8DAP3/BAD8/wMA/f8DAP7/AQD//wEAAAD//wEA/v8CAAAA/v8CAP7/AgD//wAAAAAAAAAAAQD+/wIA//8AAAEA/v8DAPz/BAD9/wIA//8AAP//AgD//wEA/v8BAAAAAQD//wAAAAAAAAEA//8AAAEA//8BAP//AAABAP//AQD+/wIA/v8DAPz/BAD8/wQA/f8BAAAAAQD+/wMA/P8DAP//AAAAAAAAAAD//wMA+/8FAP3/AQABAP3/BAD8/wMA/v8BAAAA//8CAP3/AwD+/wEAAQD9/wMA/f8EAPz/BAD7/wQA/v8BAAEA/f8DAP7/AQAAAP//AgD+/wEAAAD//wIA/v8CAP7/AgD+/wEAAQD//wEA/v8CAP7/BAD7/wQA/f8CAAAA//8AAAAAAAABAP//AQD+/wEAAQD+/wMA/f8BAAEA/v8DAPz/AwD/////AwD8/wQA/P8DAP7/AgD//wAA//8BAAAAAAAAAP//AgD+/wEAAAD//wIA/v8BAAAA//8CAP3/AgD//wAAAQD+/wIA/v8BAAAA//8CAP7/AgD+/wEA//8CAP3/BAD7/wQA/v8BAAAA//8AAAEAAAD//wIA/f8DAP7/AgD+/wIA/v8CAP7/AgD+/wEAAAAAAP//AgD9/wMA/v8BAP//AgD9/wMA/v8AAAEA//8BAP//AQD//wEA//8AAAEA/v8EAPz/AgD//wAAAQAAAP//AAABAP//AQD//wEAAAD//wEA//8BAAEA/f8DAP7/AQABAP3/AwD+/wIA/////wEAAAAAAAAAAAD//wIA/v8CAP////8CAP7/AgD//wAA//8CAP3/BAD9/wAAAgD9/wMA/v8BAP//AQAAAP//AQAAAP//AgD9/wMA/f8EAPz/AwD+/wEAAAAAAAAAAAD//wIA/f8EAP3/AAABAAAA//8CAP7/AQAAAP//AQAAAAAA//8BAP//AQAAAP//AQAAAP//AQAAAP//AgD9/wMA/v8BAP//AQAAAP//AQD//wIA/v8CAP3/BAD9/wEAAAD//wEAAQD9/wMA/f8CAAAA/v8DAP3/AgD//wAAAQD+/wIA/v8CAP7/AQAAAP//AgD+/wEAAAAAAP//AwD7/wUA/f8BAAEA/v8BAAEA/v8DAP3/AgD//wEA//8BAP//AQD//wEA//8CAP3/BAD7/wQA/////wIA/v8AAAIA/v8CAP3/BAD7/wUA/P8DAP3/AwD9/wMA/v8AAAIA/v8CAP7/AgD+/wIA//8AAAEA/v8CAP7/AgD//wAAAAD//wEAAAAAAAAA//8BAP7/BAD7/wUA/P8CAAAA//8BAP//AQAAAP//AgD9/wMA/v8BAAAA//8BAAAA//8CAP3/AwD+/wEA//8CAP3/AwD+/wAAAwD8/wIAAAD//wIA/////wIA/v8CAP7/AgD+/wEAAAAAAAAAAAAAAP//AgD+/wIA//8AAAAA//8CAP7/AgD+/wEA//8CAP3/AwD9/wMA/v8BAP7/AwD9/wMA/f8CAP//AQD+/wIA//8BAP//AQD+/wMA/v8BAAAA//8BAAAA//8CAP7/AQAAAP//AgD+/wIA/v8CAP//AAAAAAEA//8BAP//AAABAAAA//8BAP//AQD//wEA//8BAP//AQAAAP//AQD//wEAAAD//wIA/f8CAAAA//8BAAAA//8BAP//AAABAP//AQD//wAAAAAAAAEA/v8CAP//AQD//wAAAAABAP7/AwD9/wIAAAD+/wIA//8BAP//AgD9/wMA/f8DAP7/AgD+/wEAAAAAAAEA/v8CAP7/AgD//wAAAAAAAAAAAAAAAP//AgD/////AgD9/wQA/f8BAAAAAAAAAAEA/f8DAP////8DAP3/AQABAP7/AgD//wAAAQD+/wMA/f8CAP7/AQABAP7/AwD7/wYA+v8FAP3/AQABAP7/AgD+/wMA/f8CAP7/AwD+/wEA//8BAP//AQAAAP7/BQD5/wcA+v8FAPz/AwD+/wIA/v8BAAAA//8DAPv/BQD8/wMA/////wEAAAAAAAAAAAD//wIA/f8DAP7/AQAAAP//AQAAAP//AgD+/wIA/v8BAAEA/f8EAPz/AwD+/wEA//8CAP7/AQD//wEA//8CAP7/AQAAAP//AgD+/wEAAAAAAAAAAAAAAAAAAAD//wIA/f8EAPz/AwD+/wEA//8CAP7/AgD+/wEAAQD+/wEAAQD+/wIA/////wIA//8AAAAAAAAAAAAAAAD//wEAAAAAAP//AgD9/wMA/v8BAP//AQAAAP//AQD//wEA//8BAP//AQD//wEA//8BAP//AQAAAP7/AwD9/wMA/v8BAP7/AwD9/wMA/v8BAP//AAABAP//AQD//wAAAAABAP//AAAAAAAAAQD//wEA/v8CAAAA/v8EAPv/BAD9/wIAAAD+/wMA/P8DAP//AAAAAP//AQD//wIA/f8DAP3/AwD9/wMA/v8BAAAA//8BAAAA//8CAP3/AwD9/wQA+/8FAPv/BQD8/wMA/v8BAAAA//8BAP//AgD+/wEAAAD//wIA/v8BAAEA/f8DAP3/AgAAAP//AQD//wAAAQD//wEA//8BAP//AQD//wEA/v8DAP3/AgAAAP7/AwD9/wIAAAD//wEAAAD//wIA/f8DAP7/AgD9/wQA+/8FAPz/AgAAAP//AgD9/wIA//8BAP//AQD//wEA//8BAP//AQD//wIA/f8DAP3/AgD//wAAAQD+/wIA/v8BAAEA/v8CAP7/AgD+/wMA/P8DAP//AAABAP7/AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEA/v8CAP3/BAD8/wMA/v8BAAAAAAD//wEAAAAAAAAAAAD//wEAAAAAAAAA//8BAP//AgD+/wEA//8CAP3/AwD9/wMA/f8EAPv/BAD+/wAAAQD//wEA//8BAP//AAABAP//AQD//wEAAAD//wEA//8BAP//AgD9/wMA/v8AAAIA/f8DAP7/AAACAP3/AwD+/wEA//8BAP//AQAAAP//AQAAAP7/AwD9/wMA/v8AAAEA//8BAP//AAAAAAEA//8AAAEA/v8CAP//AAAAAAEA/v8DAPz/BAD9/wEAAQD+/wEAAQD9/wQA/P8DAP7/AQAAAAAAAAAAAAAAAAAAAAAAAQD+/wIA/////wIA/v8BAAAA//8BAP//AQD//wEA//8BAAAA/v8EAPz/AwD///7/BAD8/wMA/////wIA/v8CAP////8CAP7/AgD+/wIA/v8CAP////8CAP7/AwD9/wIA/v8CAP//AAABAP7/AwD9/wEAAQD+/wMA/f8CAP//AAAAAAEA/v8DAPz/BAD9/wIA/v8CAP7/AgD//wAAAAD//wIA/v8CAP7/AQAAAAAA//8CAP7/AgD+/wIA/v8CAP7/AwD8/wUA+v8GAPv/AwD//wAAAAAAAAAA//8DAPv/BQD9/wAAAgD9/wMA/v8BAP//AQAAAP//AgD9/wMA/v8BAAAA//8BAAAAAAAAAP//AQAAAAAAAAD//wEA//8CAP3/AwD+/wAAAgD+/wEAAAD//wIA/v8CAP7/AgD/////AwD8/wUA/P8CAP//AQD//wIA/f8DAP3/AwD+/wAAAQD+/wMA/f8DAP3/AgD//wAAAQD//wEA//8BAP7/AwD+/wEA//8AAAEA//8CAPz/BAD9/wIA//8AAAEA/v8DAPz/BAD9/wIA//8AAAEA/v8CAP7/AgD//wEA/f8EAPz/BAD+////AgD//wAAAQD//wAAAQD//wEA//8BAP7/AwD+/wEA"
            }
        } catch (i) {
            return void addTest("audiopreload", !1)
        }
        n.setAttribute("preload", "auto"), n.style.cssText = "display:none", docElement.appendChild(n), setTimeout(function () {
            n.addEventListener("loadeddata", A, !1), e = setTimeout(A, t)
        }, 0)
    }), Modernizr.addTest("canvasblending", function () {
        if (Modernizr.canvas === !1) return !1;
        var A = createElement("canvas").getContext("2d");
        try {
            A.globalCompositeOperation = "screen"
        } catch (e) {}
        return "screen" === A.globalCompositeOperation
    });
    var canvas = createElement("canvas");
    Modernizr.addTest("todataurljpeg", function () {
        return !!Modernizr.canvas && 0 === canvas.toDataURL("image/jpeg").indexOf("data:image/jpeg")
    }), Modernizr.addTest("todataurlpng", function () {
        return !!Modernizr.canvas && 0 === canvas.toDataURL("image/png").indexOf("data:image/png")
    }), Modernizr.addTest("todataurlwebp", function () {
        var A = !1;
        try {
            A = !!Modernizr.canvas && 0 === canvas.toDataURL("image/webp").indexOf("data:image/webp")
        } catch (e) {}
        return A
    }), Modernizr.addTest("canvaswinding", function () {
        if (Modernizr.canvas === !1) return !1;
        var A = createElement("canvas").getContext("2d");
        return A.rect(0, 0, 10, 10), A.rect(2, 2, 6, 6), A.isPointInPath(5, 5, "evenodd") === !1
    }), Modernizr.addTest("bgpositionshorthand", function () {
        var A = createElement("a"),
            e = A.style,
            t = "right 10px bottom 10px";
        return e.cssText = "background-position: " + t + ";", e.backgroundPosition === t
    }), Modernizr.addTest("csscalc", function () {
        var A = "width:",
            e = "calc(10px);",
            t = createElement("a");
        return t.style.cssText = A + prefixes.join(e + A), !!t.style.length
    }), Modernizr.addTest("cubicbezierrange", function () {
        var A = createElement("a");
        return A.style.cssText = prefixes.join("transition-timing-function:cubic-bezier(1,0,0,1.1); "), !!A.style.length
    }), Modernizr.addTest("cssgradients", function () {
        for (var A, e = "background-image:", t = "gradient(linear,left top,right bottom,from(#9f9),to(white));", n = "", r = 0, i = prefixes.length - 1; i > r; r++) A = 0 === r ? "to " : "", n += e + prefixes[r] + "linear-gradient(" + A + "left top, #9f9, white);";
        Modernizr._config.usePrefixes && (n += e + "-webkit-" + t);
        var o = createElement("a"),
            d = o.style;
        return d.cssText = n, ("" + d.backgroundImage).indexOf("gradient") > -1
    }), Modernizr.addTest("multiplebgs", function () {
        var A = createElement("a").style;
        return A.cssText = "background:url(https://),url(https://),red url(https://)", /(url\s*\(.*?){3}/.test(A.background)
    }), Modernizr.addTest("opacity", function () {
        var A = createElement("a").style;
        return A.cssText = prefixes.join("opacity:.55;"), /^0.55$/.test(A.opacity)
    }), Modernizr.addTest("csspointerevents", function () {
        var A = createElement("a").style;
        return A.cssText = "pointer-events:auto", "auto" === A.pointerEvents
    }), Modernizr.addTest("csspositionsticky", function () {
        var A = "position:",
            e = "sticky",
            t = createElement("a"),
            n = t.style;
        return n.cssText = A + prefixes.join(e + ";" + A).slice(0, -A.length), -1 !== n.position.indexOf(e)
    }), Modernizr.addTest("regions", function () {
        if (isSVG) return !1;
        var A = Modernizr.prefixed("flowFrom"),
            e = Modernizr.prefixed("flowInto"),
            t = !1;
        if (!A || !e) return t;
        var n = createElement("iframe"),
            r = createElement("div"),
            i = createElement("div"),
            o = createElement("div"),
            d = "modernizr_flow_for_regions_check";
        i.innerText = "M", r.style.cssText = "top: 150px; left: 150px; padding: 0px;", o.style.cssText = "width: 50px; height: 50px; padding: 42px;", o.style[A] = d, r.appendChild(i), r.appendChild(o), docElement.appendChild(r);
        var a, s, l = i.getBoundingClientRect();
        return i.style[e] = d, a = i.getBoundingClientRect(), s = parseInt(a.left - l.left, 10), docElement.removeChild(r), 42 == s ? t = !0 : (docElement.appendChild(n), l = n.getBoundingClientRect(), n.style[e] = d, a = n.getBoundingClientRect(), l.height > 0 && l.height !== a.height && 0 === a.height && (t = !0)), i = o = r = n = undefined, t
    }), Modernizr.addTest("cssremunit", function () {
        var A = createElement("a").style;
        try {
            A.fontSize = "3rem"
        } catch (e) {}
        return /rem/.test(A.fontSize)
    }), Modernizr.addTest("rgba", function () {
        var A = createElement("a").style;
        return A.cssText = "background-color:rgba(150,255,150,.5)", ("" + A.backgroundColor).indexOf("rgba") > -1
    }), Modernizr.addTest("preserve3d", function () {
        var A = createElement("a"),
            e = createElement("a");
        A.style.cssText = "display: block; transform-style: preserve-3d; transform-origin: right; transform: rotateY(40deg);", e.style.cssText = "display: block; width: 9px; height: 1px; background: #000; transform-origin: right; transform: rotateY(40deg);", A.appendChild(e), docElement.appendChild(A);
        var t = e.getBoundingClientRect();
        return docElement.removeChild(A), t.width && t.width < 4
    }), Modernizr.addTest("createelementattrs", function () {
        try {
            return "test" == createElement('<input name="test" />').getAttribute("name")
        } catch (A) {
            return !1
        }
    }, {
        aliases: ["createelement-attrs"]
    }), Modernizr.addTest("dataset", function () {
        var A = createElement("div");
        return A.setAttribute("data-a-b", "c"), !(!A.dataset || "c" !== A.dataset.aB)
    }), Modernizr.addTest("hidden", "hidden" in createElement("a")), Modernizr.addTest("bdi", function () {
        var A = createElement("div"),
            e = createElement("bdi");
        e.innerHTML = "&#1573;", A.appendChild(e), docElement.appendChild(A);
        var t = "rtl" === (window.getComputedStyle ? getComputedStyle(e, null) : e.currentStyle).direction;
        return docElement.removeChild(A), t
    }), Modernizr.addTest("outputelem", "value" in createElement("output")), Modernizr.addTest("progressbar", createElement("progress").max !== undefined), Modernizr.addTest("meter", createElement("meter").max !== undefined), Modernizr.addTest("ruby", function () {
        function A(A, e) {
            var t;
            return window.getComputedStyle ? t = document.defaultView.getComputedStyle(A, null).getPropertyValue(e) : A.currentStyle && (t = A.currentStyle[e]), t
        }

        function e() {
            docElement.removeChild(t), t = null, n = null, r = null
        }
        var t = createElement("ruby"),
            n = createElement("rt"),
            r = createElement("rp"),
            i = "display",
            o = "fontSize";
        return t.appendChild(r), t.appendChild(n), docElement.appendChild(t), "none" == A(r, i) || "ruby" == A(t, i) && "ruby-text" == A(n, i) || "6pt" == A(r, o) && "6pt" == A(n, o) ? (e(), !0) : (e(), !1)
    }), Modernizr.addTest("template", "content" in createElement("template")), Modernizr.addTest("time", "valueAsDate" in createElement("time")), Modernizr.addTest("texttrackapi", "function" == typeof createElement("video").addTextTrack), Modernizr.addTest("track", "kind" in createElement("track")), Modernizr.addTest("unknownelements", function () {
        var A = createElement("a");
        return A.innerHTML = "<xyz></xyz>", 1 === A.childNodes.length
    }), Modernizr.addTest("capture", "capture" in createElement("input")), Modernizr.addTest("fileinput", function () {
        if (navigator.userAgent.match(/(Android (1.0|1.1|1.5|1.6|2.0|2.1))|(Windows Phone (OS 7|8.0))|(XBLWP)|(ZuneWP)|(w(eb)?OSBrowser)|(webOS)|(Kindle\/(1.0|2.0|2.5|3.0))/)) return !1;
        var A = createElement("input");
        return A.type = "file", !A.disabled
    }), Modernizr.addTest("fileinputdirectory", function () {
        var A = createElement("input"),
            e = "directory";
        if (A.type = "file", e in A) return !0;
        for (var t = 0, n = domPrefixes.length; n > t; t++)
            if (domPrefixes[t] + e in A) return !0;
        return !1
    }), Modernizr.addTest("formattribute", function () {
        var A, e = createElement("form"),
            t = createElement("input"),
            n = createElement("div"),
            r = "formtest" + (new Date).getTime(),
            i = !1;
        e.id = r;
        try {
            t.setAttribute("form", r)
        } catch (o) {
            document.createAttribute && (A = document.createAttribute("form"), A.nodeValue = r, t.setAttributeNode(A))
        }
        return n.appendChild(e), n.appendChild(t), docElement.appendChild(n), i = e.elements && 1 === e.elements.length && t.form == e, n.parentNode.removeChild(n), i
    }), Modernizr.addTest("placeholder", "placeholder" in createElement("input") && "placeholder" in createElement("textarea")), Modernizr.addTest("sandbox", "sandbox" in createElement("iframe")), Modernizr.addTest("seamless", "seamless" in createElement("iframe")), Modernizr.addTest("srcdoc", "srcdoc" in createElement("iframe")), Modernizr.addAsyncTest(function () {
        if (!Modernizr.canvas) return !1;
        var A = new Image,
            e = createElement("canvas"),
            t = e.getContext("2d");
        A.onload = function () {
            addTest("apng", function () {
                return "undefined" == typeof e.getContext ? !1 : (t.drawImage(A, 0, 0), 0 === t.getImageData(0, 0, 1, 1).data[3])
            })
        }, A.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACGFjVEwAAAABAAAAAcMq2TYAAAANSURBVAiZY2BgYPgPAAEEAQB9ssjfAAAAGmZjVEwAAAAAAAAAAQAAAAEAAAAAAAAAAAD6A+gBAbNU+2sAAAARZmRBVAAAAAEImWNgYGBgAAAABQAB6MzFdgAAAABJRU5ErkJggg=="
    }), Modernizr.addTest("imgcrossorigin", "crossOrigin" in createElement("img")), Modernizr.addAsyncTest(function () {
        var A, e, t, n = createElement("img"),
            r = "sizes" in n;
        !r && "srcset" in n ? (e = "data:image/gif;base64,R0lGODlhAgABAPAAAP///wAAACH5BAAAAAAALAAAAAACAAEAAAICBAoAOw==", A = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", t = function () {
            addTest("sizes", 2 == n.width)
        }, n.onload = t, n.onerror = t, n.setAttribute("sizes", "9px"), n.srcset = A + " 1w," + e + " 8w", n.src = A) : addTest("sizes", r)
    }), Modernizr.addTest("srcset", "srcset" in createElement("img")), Modernizr.addTest("inputformaction", !!("formAction" in createElement("input")), {
        aliases: ["input-formaction"]
    }), Modernizr.addTest("inputformenctype", !!("formEnctype" in createElement("input")), {
        aliases: ["input-formenctype"]
    }), Modernizr.addTest("inputformmethod", !!("formMethod" in createElement("input"))), Modernizr.addTest("inputformtarget", !!("formtarget" in createElement("input")), {
        aliases: ["input-formtarget"]
    }), Modernizr.addTest("scriptasync", "async" in createElement("script")), Modernizr.addTest("scriptdefer", "defer" in createElement("script")), Modernizr.addTest("stylescoped", "scoped" in createElement("style")), Modernizr.addTest("inlinesvg", function () {
        var A = createElement("div");
        return A.innerHTML = "<svg/>", "http://www.w3.org/2000/svg" == ("undefined" != typeof SVGRect && A.firstChild && A.firstChild.namespaceURI)
    }), Modernizr.addTest("textareamaxlength", !!("maxLength" in createElement("textarea"))), Modernizr.addAsyncTest(function () {
        function A(o) {
            r++, clearTimeout(e);
            var d = o && "playing" === o.type || 0 !== i.currentTime;
            return !d && n > r ? void(e = setTimeout(A, t)) : (i.removeEventListener("playing", A, !1), addTest("videoautoplay", d), void i.parentNode.removeChild(i))
        }
        var e, t = 200,
            n = 5,
            r = 0,
            i = createElement("video"),
            o = i.style;
        if (!(Modernizr.video && "autoplay" in i)) return void addTest("videoautoplay", !1);
        o.position = "absolute", o.height = 0, o.width = 0;
        try {
            if (Modernizr.video.ogg) i.src = "data:video/ogg;base64,T2dnUwACAAAAAAAAAABmnCATAAAAAHDEixYBKoB0aGVvcmEDAgEAAQABAAAQAAAQAAAAAAAFAAAAAQAAAAAAAAAAAGIAYE9nZ1MAAAAAAAAAAAAAZpwgEwEAAAACrA7TDlj///////////////+QgXRoZW9yYSsAAABYaXBoLk9yZyBsaWJ0aGVvcmEgMS4xIDIwMDkwODIyIChUaHVzbmVsZGEpAQAAABoAAABFTkNPREVSPWZmbXBlZzJ0aGVvcmEtMC4yOYJ0aGVvcmG+zSj3uc1rGLWpSUoQc5zmMYxSlKQhCDGMYhCEIQhAAAAAAAAAAAAAEW2uU2eSyPxWEvx4OVts5ir1aKtUKBMpJFoQ/nk5m41mUwl4slUpk4kkghkIfDwdjgajQYC8VioUCQRiIQh8PBwMhgLBQIg4FRba5TZ5LI/FYS/Hg5W2zmKvVoq1QoEykkWhD+eTmbjWZTCXiyVSmTiSSCGQh8PB2OBqNBgLxWKhQJBGIhCHw8HAyGAsFAiDgUCw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDAwPEhQUFQ0NDhESFRUUDg4PEhQVFRUOEBETFBUVFRARFBUVFRUVEhMUFRUVFRUUFRUVFRUVFRUVFRUVFRUVEAwLEBQZGxwNDQ4SFRwcGw4NEBQZHBwcDhATFhsdHRwRExkcHB4eHRQYGxwdHh4dGxwdHR4eHh4dHR0dHh4eHRALChAYKDM9DAwOExo6PDcODRAYKDlFOA4RFh0zV1A+EhYlOkRtZ00YIzdAUWhxXDFATldneXhlSFxfYnBkZ2MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEhIVGRoaGhoSFBYaGhoaGhUWGRoaGhoaGRoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhESFh8kJCQkEhQYIiQkJCQWGCEkJCQkJB8iJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQREhgvY2NjYxIVGkJjY2NjGBo4Y2NjY2MvQmNjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRISEhUXGBkbEhIVFxgZGxwSFRcYGRscHRUXGBkbHB0dFxgZGxwdHR0YGRscHR0dHhkbHB0dHR4eGxwdHR0eHh4REREUFxocIBERFBcaHCAiERQXGhwgIiUUFxocICIlJRcaHCAiJSUlGhwgIiUlJSkcICIlJSUpKiAiJSUlKSoqEBAQFBgcICgQEBQYHCAoMBAUGBwgKDBAFBgcICgwQEAYHCAoMEBAQBwgKDBAQEBgICgwQEBAYIAoMEBAQGCAgAfF5cdH1e3Ow/L66wGmYnfIUbwdUTe3LMRbqON8B+5RJEvcGxkvrVUjTMrsXYhAnIwe0dTJfOYbWrDYyqUrz7dw/JO4hpmV2LsQQvkUeGq1BsZLx+cu5iV0e0eScJ91VIQYrmqfdVSK7GgjOU0oPaPOu5IcDK1mNvnD+K8LwS87f8Jx2mHtHnUkTGAurWZlNQa74ZLSFH9oF6FPGxzLsjQO5Qe0edcpttd7BXBSqMCL4k/4tFrHIPuEQ7m1/uIWkbDMWVoDdOSuRQ9286kvVUlQjzOE6VrNguN4oRXYGkgcnih7t13/9kxvLYKQezwLTrO44sVmMPgMqORo1E0sm1/9SludkcWHwfJwTSybR4LeAz6ugWVgRaY8mV/9SluQmtHrzsBtRF/wPY+X0JuYTs+ltgrXAmlk10xQHmTu9VSIAk1+vcvU4ml2oNzrNhEtQ3CysNP8UeR35wqpKUBdGdZMSjX4WVi8nJpdpHnbhzEIdx7mwf6W1FKAiucMXrWUWVjyRf23chNtR9mIzDoT/6ZLYailAjhFlZuvPtSeZ+2oREubDoWmT3TguY+JHPdRVSLKxfKH3vgNqJ/9emeEYikGXDFNzaLjvTeGAL61mogOoeG3y6oU4rW55ydoj0lUTSR/mmRhPmF86uwIfzp3FtiufQCmppaHDlGE0r2iTzXIw3zBq5hvaTldjG4CPb9wdxAme0SyedVKczJ9AtYbgPOzYKJvZZImsN7ecrxWZg5dR6ZLj/j4qpWsIA+vYwE+Tca9ounMIsrXMB4Stiib2SPQtZv+FVIpfEbzv8ncZoLBXc3YBqTG1HsskTTotZOYTG+oVUjLk6zhP8bg4RhMUNtfZdO7FdpBuXzhJ5Fh8IKlJG7wtD9ik8rWOJxy6iQ3NwzBpQ219mlyv+FLicYs2iJGSE0u2txzed++D61ZWCiHD/cZdQVCqkO2gJpdpNaObhnDfAPrT89RxdWFZ5hO3MseBSIlANppdZNIV/Rwe5eLTDvkfWKzFnH+QJ7m9QWV1KdwnuIwTNtZdJMoXBf74OhRnh2t+OTGL+AVUnIkyYY+QG7g9itHXyF3OIygG2s2kud679ZWKqSFa9n3IHD6MeLv1lZ0XyduRhiDRtrNnKoyiFVLcBm0ba5Yy3fQkDh4XsFE34isVpOzpa9nR8iCpS4HoxG2rJpnRhf3YboVa1PcRouh5LIJv/uQcPNd095ickTaiGBnWLKVWRc0OnYTSyex/n2FofEPnDG8y3PztHrzOLK1xo6RAml2k9owKajOC0Wr4D5x+3nA0UEhK2m198wuBHF3zlWWVKWLN1CHzLClUfuoYBcx4b1llpeBKmbayaR58njtE9onD66lUcsg0Spm2snsb+8HaJRn4dYcLbCuBuYwziB8/5U1C1DOOz2gZjSZtrLJk6vrLF3hwY4Io9xuT/ruUFRSBkNtUzTOWhjh26irLEPx4jPZL3Fo3QrReoGTTM21xYTT9oFdhTUIvjqTkfkvt0bzgVUjq/hOYY8j60IaO/0AzRBtqkTS6R5ellZd5uKdzzhb8BFlDdAcrwkE0rbXTOPB+7Y0FlZO96qFL4Ykg21StJs8qIW7h16H5hGiv8V2Cflau7QVDepTAHa6Lgt6feiEvJDM21StJsmOH/hynURrKxvUpQ8BH0JF7BiyG2qZpnL/7AOU66gt+reLEXY8pVOCQvSsBtqZTNM8bk9ohRcwD18o/WVkbvrceVKRb9I59IEKysjBeTMmmbA21xu/6iHadLRxuIzkLpi8wZYmmbbWi32RVAUjruxWlJ//iFxE38FI9hNKOoCdhwf5fDe4xZ81lgREhK2m1j78vW1CqkuMu/AjBNK210kzRUX/B+69cMMUG5bYrIeZxVSEZISmkzbXOi9yxwIfPgdsov7R71xuJ7rFcACjG/9PzApqFq7wEgzNJm2suWESPuwrQvejj7cbnQxMkxpm21lUYJL0fKmogPPqywn7e3FvB/FCNxPJ85iVUkCE9/tLKx31G4CgNtWTTPFhMvlu8G4/TrgaZttTChljfNJGgOT2X6EqpETy2tYd9cCBI4lIXJ1/3uVUllZEJz4baqGF64yxaZ+zPLYwde8Uqn1oKANtUrSaTOPHkhvuQP3bBlEJ/LFe4pqQOHUI8T8q7AXx3fLVBgSCVpMba55YxN3rv8U1Dv51bAPSOLlZWebkL8vSMGI21lJmmeVxPRwFlZF1CpqCN8uLwymaZyjbXHCRytogPN3o/n74CNykfT+qqRv5AQlHcRxYrC5KvGmbbUwmZY/29BvF6C1/93x4WVglXDLFpmbapmF89HKTogRwqqSlGbu+oiAkcWFbklC6Zhf+NtTLFpn8oWz+HsNRVSgIxZWON+yVyJlE5tq/+GWLTMutYX9ekTySEQPLVNQQ3OfycwJBM0zNtZcse7CvcKI0V/zh16Dr9OSA21MpmmcrHC+6pTAPHPwoit3LHHqs7jhFNRD6W8+EBGoSEoaZttTCZljfduH/fFisn+dRBGAZYtMzbVMwvul/T/crK1NQh8gN0SRRa9cOux6clC0/mDLFpmbarmF8/e6CopeOLCNW6S/IUUg3jJIYiAcDoMcGeRbOvuTPjXR/tyo79LK3kqqkbxkkMRAOB0GODPItnX3Jnxro/25Ud+llbyVVSN4ySGIgHA6DHBnkWzr7kz410f7cqO/Syt5KqpFVJwn6gBEvBM0zNtZcpGOEPiysW8vvRd2R0f7gtjhqUvXL+gWVwHm4XJDBiMpmmZtrLfPwd/IugP5+fKVSysH1EXreFAcEhelGmbbUmZY4Xdo1vQWVnK19P4RuEnbf0gQnR+lDCZlivNM22t1ESmopPIgfT0duOfQrsjgG4tPxli0zJmF5trdL1JDUIUT1ZXSqQDeR4B8mX3TrRro/2McGeUvLtwo6jIEKMkCUXWsLyZROd9P/rFYNtXPBli0z398iVUlVKAjFlY437JXImUTm2r/4ZYtMy61hf16RPJIU9nZ1MABAwAAAAAAAAAZpwgEwIAAABhp658BScAAAAAAADnUFBQXIDGXLhwtttNHDhw5OcpQRMETBEwRPduylKVB0HRdF0A";
            else {
                if (!Modernizr.video.h264) return void addTest("videoautoplay", !1);
                i.src = "data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAAIZnJlZQAAAs1tZGF0AAACrgYF//+q3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE0OCByMjYwMSBhMGNkN2QzIC0gSC4yNjQvTVBFRy00IEFWQyBjb2RlYyAtIENvcHlsZWZ0IDIwMDMtMjAxNSAtIGh0dHA6Ly93d3cudmlkZW9sYW4ub3JnL3gyNjQuaHRtbCAtIG9wdGlvbnM6IGNhYmFjPTEgcmVmPTMgZGVibG9jaz0xOjA6MCBhbmFseXNlPTB4MzoweDExMyBtZT1oZXggc3VibWU9NyBwc3k9MSBwc3lfcmQ9MS4wMDowLjAwIG1peGVkX3JlZj0xIG1lX3JhbmdlPTE2IGNocm9tYV9tZT0xIHRyZWxsaXM9MSA4eDhkY3Q9MSBjcW09MCBkZWFkem9uZT0yMSwxMSBmYXN0X3Bza2lwPTEgY2hyb21hX3FwX29mZnNldD0tMiB0aHJlYWRzPTEgbG9va2FoZWFkX3RocmVhZHM9MSBzbGljZWRfdGhyZWFkcz0wIG5yPTAgZGVjaW1hdGU9MSBpbnRlcmxhY2VkPTAgYmx1cmF5X2NvbXBhdD0wIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PTI1MCBrZXlpbnRfbWluPTEwIHNjZW5lY3V0PTQwIGludHJhX3JlZnJlc2g9MCByY19sb29rYWhlYWQ9NDAgcmM9Y3JmIG1idHJlZT0xIGNyZj0yMy4wIHFjb21wPTAuNjAgcXBtaW49MCBxcG1heD02OSBxcHN0ZXA9NCBpcF9yYXRpbz0xLjQwIGFxPTE6MS4wMACAAAAAD2WIhAA3//728P4FNjuZQQAAAu5tb292AAAAbG12aGQAAAAAAAAAAAAAAAAAAAPoAAAAZAABAAABAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAACGHRyYWsAAABcdGtoZAAAAAMAAAAAAAAAAAAAAAEAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAgAAAAIAAAAAACRlZHRzAAAAHGVsc3QAAAAAAAAAAQAAAGQAAAAAAAEAAAAAAZBtZGlhAAAAIG1kaGQAAAAAAAAAAAAAAAAAACgAAAAEAFXEAAAAAAAtaGRscgAAAAAAAAAAdmlkZQAAAAAAAAAAAAAAAFZpZGVvSGFuZGxlcgAAAAE7bWluZgAAABR2bWhkAAAAAQAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAA+3N0YmwAAACXc3RzZAAAAAAAAAABAAAAh2F2YzEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAgACAEgAAABIAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY//8AAAAxYXZjQwFkAAr/4QAYZ2QACqzZX4iIhAAAAwAEAAADAFA8SJZYAQAGaOvjyyLAAAAAGHN0dHMAAAAAAAAAAQAAAAEAAAQAAAAAHHN0c2MAAAAAAAAAAQAAAAEAAAABAAAAAQAAABRzdHN6AAAAAAAAAsUAAAABAAAAFHN0Y28AAAAAAAAAAQAAADAAAABidWR0YQAAAFptZXRhAAAAAAAAACFoZGxyAAAAAAAAAABtZGlyYXBwbAAAAAAAAAAAAAAAAC1pbHN0AAAAJal0b28AAAAdZGF0YQAAAAEAAAAATGF2ZjU2LjQwLjEwMQ=="
            }
        } catch (d) {
            return void addTest("videoautoplay", !1)
        }
        i.setAttribute("autoplay", ""), i.style.cssText = "display:none", docElement.appendChild(i), setTimeout(function () {
            i.addEventListener("playing", A, !1), e = setTimeout(A, t)
        }, 0)
    }), Modernizr.addTest("videoloop", "loop" in createElement("video")), Modernizr.addTest("videopreload", "preload" in createElement("video")), Modernizr.addAsyncTest(function () {
        if (Modernizr.webglextensions = new Boolean(!1), Modernizr.webgl) {
            var A, e, t;
            try {
                A = createElement("canvas"), e = A.getContext("webgl") || A.getContext("experimental-webgl"), t = e.getSupportedExtensions()
            } catch (n) {
                return
            }
            e !== undefined && (Modernizr.webglextensions = new Boolean(!0));
            for (var r = -1, i = t.length; ++r < i;) Modernizr.webglextensions[t[r]] = !0;
            A = undefined
        }
    }), Modernizr.addAsyncTest(function () {
        var A, e, t = function (A) {
                docElement.contains(A) || docElement.appendChild(A)
            },
            n = function (A) {
                A.fake && A.parentNode && A.parentNode.removeChild(A)
            },
            r = function (A, e) {
                var t = !!A;
                if (t && (t = new Boolean(t), t.blocked = "blocked" === A), addTest("flash", function () {
                        return t
                    }), e && s.contains(e)) {
                    for (; e.parentNode !== s;) e = e.parentNode;
                    s.removeChild(e)
                }
            };
        try {
            e = "ActiveXObject" in window && "Pan" in new window.ActiveXObject("ShockwaveFlash.ShockwaveFlash")
        } catch (i) {}
        if (A = !("plugins" in navigator && "Shockwave Flash" in navigator.plugins || e), A || isSVG) r(!1);
        else {
            var o, d, a = createElement("embed"),
                s = getBody();
            if (a.type = "application/x-shockwave-flash", s.appendChild(a), !("Pan" in a || e)) return t(s), r("blocked", a), void n(s);
            o = function () {
                return t(s), docElement.contains(s) ? (docElement.contains(a) ? (d = a.style.cssText, "" !== d ? r("blocked", a) : r(!0, a)) : r("blocked"), void n(s)) : (s = document.body || s, a = createElement("embed"), a.type = "application/x-shockwave-flash", s.appendChild(a), setTimeout(o, 1e3))
            }, setTimeout(o, 10)
        }
    });
    var mq = function () {
        var A = window.matchMedia || window.msMatchMedia;
        return A ? function (e) {
            var t = A(e);
            return t && t.matches || !1
        } : function (A) {
            var e = !1;
            return injectElementWithStyles("@media " + A + " { #modernizr { position: absolute; } }", function (A) {
                e = "absolute" == (window.getComputedStyle ? window.getComputedStyle(A, null) : A.currentStyle).position
            }), e
        }
    }();
    ModernizrProto.mq = mq, Modernizr.addTest("mediaqueries", mq("only all"));
    var testStyles = ModernizrProto.testStyles = injectElementWithStyles;
    Modernizr.addTest("hiddenscroll", function () {
        return testStyles("#modernizr {width:100px;height:100px;overflow:scroll}", function (A) {
            return A.offsetWidth === A.clientWidth
        })
    }), Modernizr.addTest("mathml", function () {
        var A;
        return testStyles("#modernizr{position:absolute;display:inline-block}", function (e) {
            e.innerHTML += "<math><mfrac><mi>xx</mi><mi>yy</mi></mfrac></math>", A = e.offsetHeight > e.offsetWidth
        }), A
    }), Modernizr.addTest("touchevents", function () {
        var A;
        if ("ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch) A = !0;
        else {
            var e = ["@media (", prefixes.join("touch-enabled),("), "heartz", ")", "{#modernizr{top:9px;position:absolute}}"].join("");
            testStyles(e, function (e) {
                A = 9 === e.offsetTop
            })
        }
        return A
    }), Modernizr.addTest("unicoderange", function () {
        return Modernizr.testStyles('@font-face{font-family:"unicodeRange";src:local("Arial");unicode-range:U+0020,U+002E}#modernizr span{font-size:20px;display:inline-block;font-family:"unicodeRange",monospace}#modernizr .mono{font-family:monospace}', function (A) {
            for (var e = [".", ".", "m", "m"], t = 0; t < e.length; t++) {
                var n = createElement("span");
                n.innerHTML = e[t], n.className = t % 2 ? "mono" : "", A.appendChild(n), e[t] = n.clientWidth
            }
            return e[0] !== e[1] && e[2] === e[3]
        })
    }), Modernizr.addTest("unicode", function () {
        var A, e = createElement("span"),
            t = createElement("span");
        return testStyles("#modernizr{font-family:Arial,sans;font-size:300em;}", function (n) {
            e.innerHTML = isSVG ? "妇" : "&#5987;", t.innerHTML = isSVG ? "☆" : "&#9734;", n.appendChild(e), n.appendChild(t), A = "offsetWidth" in e && e.offsetWidth !== t.offsetWidth
        }), A
    }), Modernizr.addTest("checked", function () {
        return testStyles("#modernizr {position:absolute} #modernizr input {margin-left:10px} #modernizr :checked {margin-left:20px;display:block}", function (A) {
            var e = createElement("input");
            return e.setAttribute("type", "checkbox"), e.setAttribute("checked", "checked"), A.appendChild(e), 20 === e.offsetLeft
        })
    }), testStyles("#modernizr{display: table; direction: ltr}#modernizr div{display: table-cell; padding: 10px}", function (A) {
        var e, t = A.childNodes;
        e = t[0].offsetLeft < t[1].offsetLeft, Modernizr.addTest("displaytable", e, {
            aliases: ["display-table"]
        })
    }, 2);
    var blacklist = function () {
        var A = navigator.userAgent,
            e = A.match(/applewebkit\/([0-9]+)/gi) && parseFloat(RegExp.$1),
            t = A.match(/w(eb)?osbrowser/gi),
            n = A.match(/windows phone/gi) && A.match(/iemobile\/([0-9])+/gi) && parseFloat(RegExp.$1) >= 9,
            r = 533 > e && A.match(/android/gi);
        return t || r || n
    }();
    blacklist ? Modernizr.addTest("fontface", !1) : testStyles('@font-face {font-family:"font";src:url("https://")}', function (A, e) {
        var t = document.getElementById("smodernizr"),
            n = t.sheet || t.styleSheet,
            r = n ? n.cssRules && n.cssRules[0] ? n.cssRules[0].cssText : n.cssText || "" : "",
            i = /src/i.test(r) && 0 === r.indexOf(e.split(" ")[0]);
        Modernizr.addTest("fontface", i)
    }), testStyles('#modernizr{font:0/0 a}#modernizr:after{content:":)";visibility:hidden;font:7px/1 a}', function (A) {
        Modernizr.addTest("generatedcontent", A.offsetHeight >= 7)
    }), Modernizr.addTest("hairline", function () {
        return testStyles("#modernizr {border:.5px solid transparent}", function (A) {
            return 1 === A.offsetHeight
        })
    }), Modernizr.addTest("cssinvalid", function () {
        return testStyles("#modernizr input{height:0;border:0;padding:0;margin:0;width:10px} #modernizr input:invalid{width:50px}", function (A) {
            var e = createElement("input");
            return e.required = !0, A.appendChild(e), e.clientWidth > 10
        })
    }), testStyles("#modernizr div {width:100px} #modernizr :last-child{width:200px;display:block}", function (A) {
        Modernizr.addTest("lastchild", A.lastChild.offsetWidth > A.firstChild.offsetWidth)
    }, 2), testStyles("#modernizr div {width:1px} #modernizr div:nth-child(2n) {width:2px;}", function (A) {
        for (var e = A.getElementsByTagName("div"), t = !0, n = 0; 5 > n; n++) t = t && e[n].offsetWidth === n % 2 + 1;
        Modernizr.addTest("nthchild", t)
    }, 5), testStyles("#modernizr{overflow: scroll; width: 40px; height: 40px; }#" + prefixes.join("scrollbar{width:0px} #modernizr::").split("#").slice(1).join("#") + "scrollbar{width:0px}", function (A) {
        Modernizr.addTest("cssscrollbar", 40 == A.scrollWidth)
    }), Modernizr.addTest("siblinggeneral", function () {
        return testStyles("#modernizr div {width:100px} #modernizr div ~ div {width:200px;display:block}", function (A) {
            return 200 == A.lastChild.offsetWidth
        }, 2)
    }), testStyles("#modernizr{position: absolute; top: -10em; visibility:hidden; font: normal 10px arial;}#subpixel{float: left; font-size: 33.3333%;}", function (A) {
        var e = A.firstChild;
        e.innerHTML = "This is a text written in Arial", Modernizr.addTest("subpixelfont", window.getComputedStyle ? "44px" !== window.getComputedStyle(e, null).getPropertyValue("width") : !1)
    }, 1, ["subpixel"]), Modernizr.addTest("cssvalid", function () {
        return testStyles("#modernizr input{height:0;border:0;padding:0;margin:0;width:10px} #modernizr input:valid{width:50px}", function (A) {
            var e = createElement("input");
            return A.appendChild(e), e.clientWidth > 10
        })
    }), testStyles("#modernizr { height: 50vh; }", function (A) {
        var e = parseInt(window.innerHeight / 2, 10),
            t = parseInt((window.getComputedStyle ? getComputedStyle(A, null) : A.currentStyle).height, 10);
        Modernizr.addTest("cssvhunit", t == e)
    }), testStyles("#modernizr { width: 50vw; }", function (A) {
        var e = parseInt(window.innerWidth / 2, 10),
            t = parseInt((window.getComputedStyle ? getComputedStyle(A, null) : A.currentStyle).width, 10);
        Modernizr.addTest("cssvwunit", t == e)
    }), Modernizr.addTest("details", function () {
        var A, e = createElement("details");
        return "open" in e ? (testStyles("#modernizr details{display:block}", function (t) {
            t.appendChild(e), e.innerHTML = "<summary>a</summary>b", A = e.offsetHeight, e.open = !0, A = A != e.offsetHeight
        }), A) : !1
    }), Modernizr.addTest("oninput", function () {
        var A, e = createElement("input");
        if (e.setAttribute("oninput", "return"), hasEvent("oninput", docElement) || "function" == typeof e.oninput) return !0;
        try {
            var t = document.createEvent("KeyboardEvent");
            A = !1;
            var n = function (e) {
                A = !0, e.preventDefault(), e.stopPropagation()
            };
            t.initKeyEvent("keypress", !0, !0, window, !1, !1, !1, !1, 0, "e".charCodeAt(0)), docElement.appendChild(e), e.addEventListener("input", n, !1), e.focus(), e.dispatchEvent(t), e.removeEventListener("input", n, !1), docElement.removeChild(e)
        } catch (r) {
            A = !1
        }
        return A
    }), Modernizr.addTest("formvalidation", function () {
        var A = createElement("form");
        if (!("checkValidity" in A && "addEventListener" in A)) return !1;
        if ("reportValidity" in A) return !0;
        var e, t = !1;
        return Modernizr.formvalidationapi = !0, A.addEventListener("submit", function (A) {
            (!window.opera || window.operamini) && A.preventDefault(), A.stopPropagation()
        }, !1), A.innerHTML = '<input name="modTest" required="required" /><button></button>', testStyles("#modernizr form{position:absolute;top:-99999em}", function (n) {
            n.appendChild(A), e = A.getElementsByTagName("input")[0], e.addEventListener("invalid", function (A) {
                t = !0, A.preventDefault(), A.stopPropagation()
            }, !1), Modernizr.formvalidationmessage = !!e.validationMessage, A.getElementsByTagName("button")[0].click()
        }), t
    });
    var inputElem = createElement("input"),
        inputattrs = "autocomplete autofocus list placeholder max min multiple pattern required step".split(" "),
        attrs = {};
    Modernizr.input = function (A) {
        for (var e = 0, t = A.length; t > e; e++) attrs[A[e]] = !!(A[e] in inputElem);
        return attrs.list && (attrs.list = !(!createElement("datalist") || !window.HTMLDataListElement)), attrs
    }(inputattrs), Modernizr.addTest("datalistelem", Modernizr.input.list);
    var inputtypes = "search tel url email datetime date month week time datetime-local number range color".split(" "),
        inputs = {};
    Modernizr.inputtypes = function (A) {
        for (var e, t, n, r = A.length, i = "1)", o = 0; r > o; o++) inputElem.setAttribute("type", e = A[o]), n = "text" !== inputElem.type && "style" in inputElem, n && (inputElem.value = i, inputElem.style.cssText = "position:absolute;visibility:hidden;", /^range$/.test(e) && inputElem.style.WebkitAppearance !== undefined ? (docElement.appendChild(inputElem), t = document.defaultView, n = t.getComputedStyle && "textfield" !== t.getComputedStyle(inputElem, null).WebkitAppearance && 0 !== inputElem.offsetHeight, docElement.removeChild(inputElem)) : /^(search|tel)$/.test(e) || (n = /^(url|email)$/.test(e) ? inputElem.checkValidity && inputElem.checkValidity() === !1 : inputElem.value != i)), inputs[A[o]] = !!n;
        return inputs
    }(inputtypes), Modernizr.addTest("localizednumber", function () {
        if (!Modernizr.inputtypes.number) return !1;
        if (!Modernizr.formvalidation) return !1;
        var A, e = createElement("div"),
            t = getBody(),
            n = function () {
                return docElement.insertBefore(t, docElement.firstElementChild || docElement.firstChild)
            }();
        e.innerHTML = '<input type="number" value="1.0" step="0.1"/>';
        var r = e.childNodes[0];
        n.appendChild(e), r.focus();
        try {
            document.execCommand("InsertText", !1, "1,1")
        } catch (i) {}
        return A = "number" === r.type && 1.1 === r.valueAsNumber && r.checkValidity(), n.removeChild(e), t.fake && n.parentNode.removeChild(n), A
    });
    var modElem = {
        elem: createElement("modernizr")
    };
    Modernizr._q.push(function () {
        delete modElem.elem
    }), Modernizr.addTest("csschunit", function () {
        var A, e = modElem.elem.style;
        try {
            e.fontSize = "3ch", A = -1 !== e.fontSize.indexOf("ch")
        } catch (t) {
            A = !1
        }
        return A
    }), Modernizr.addTest("cssexunit", function () {
        var A, e = modElem.elem.style;
        try {
            e.fontSize = "3ex", A = -1 !== e.fontSize.indexOf("ex")
        } catch (t) {
            A = !1
        }
        return A
    }), Modernizr.addTest("hsla", function () {
        var A = createElement("a").style;
        return A.cssText = "background-color:hsla(120,40%,100%,.5)", contains(A.backgroundColor, "rgba") || contains(A.backgroundColor, "hsla")
    }), testStyles("#modernizr1{width: 50vmax}#modernizr2{width:50px;height:50px;overflow:scroll}#modernizr3{position:fixed;top:0;left:0;bottom:0;right:0}", function (A) {
        var e = A.childNodes[2],
            t = A.childNodes[1],
            n = A.childNodes[0],
            r = parseInt((t.offsetWidth - t.clientWidth) / 2, 10),
            i = n.clientWidth / 100,
            o = n.clientHeight / 100,
            d = parseInt(50 * Math.max(i, o), 10),
            a = parseInt((window.getComputedStyle ? getComputedStyle(e, null) : e.currentStyle).width, 10);
        Modernizr.addTest("cssvmaxunit", roundedEquals(d, a) || roundedEquals(d, a - r))
    }, 3), testStyles("#modernizr1{width: 50vm;width:50vmin}#modernizr2{width:50px;height:50px;overflow:scroll}#modernizr3{position:fixed;top:0;left:0;bottom:0;right:0}", function (A) {
        var e = A.childNodes[2],
            t = A.childNodes[1],
            n = A.childNodes[0],
            r = parseInt((t.offsetWidth - t.clientWidth) / 2, 10),
            i = n.clientWidth / 100,
            o = n.clientHeight / 100,
            d = parseInt(50 * Math.min(i, o), 10),
            a = parseInt((window.getComputedStyle ? getComputedStyle(e, null) : e.currentStyle).width, 10);
        Modernizr.addTest("cssvminunit", roundedEquals(d, a) || roundedEquals(d, a - r))
    }, 3);
    var testXhrType = function (A) {
        if ("undefined" == typeof XMLHttpRequest) return !1;
        var e = new XMLHttpRequest;
        e.open("get", "/", !0);
        try {
            e.responseType = A
        } catch (t) {
            return !1
        }
        return "response" in e && e.responseType == A
    };
    Modernizr.addTest("xhrresponsetypearraybuffer", testXhrType("arraybuffer")), Modernizr.addTest("xhrresponsetypeblob", testXhrType("blob")), Modernizr.addTest("xhrresponsetypedocument", testXhrType("document")), Modernizr.addTest("xhrresponsetypejson", testXhrType("json")), Modernizr.addTest("xhrresponsetypetext", testXhrType("text"));
    var toStringFn = {}.toString;
    Modernizr.addTest("svgclippaths", function () {
        return !!document.createElementNS && /SVGClipPath/.test(toStringFn.call(document.createElementNS("http://www.w3.org/2000/svg", "clipPath")))
    }), Modernizr.addTest("svgforeignobject", function () {
        return !!document.createElementNS && /SVGForeignObject/.test(toStringFn.call(document.createElementNS("http://www.w3.org/2000/svg", "foreignObject")))
    }), Modernizr.addTest("smil", function () {
        return !!document.createElementNS && /SVGAnimate/.test(toStringFn.call(document.createElementNS("http://www.w3.org/2000/svg", "animate")))
    });
    var mStyle = {
        style: modElem.elem.style
    };
    Modernizr._q.unshift(function () {
        delete mStyle.style
    });
    var testProp = ModernizrProto.testProp = function (A, e, t) {
        return testProps([A], undefined, e, t)
    };
    Modernizr.addTest("textshadow", testProp("textShadow", "1px 1px")), ModernizrProto.testAllProps = testPropsAll;
    var prefixed = ModernizrProto.prefixed = function (A, e, t) {
            return 0 === A.indexOf("@") ? atRule(A) : (-1 != A.indexOf("-") && (A = cssToDOM(A)), e ? testPropsAll(A, e, t) : testPropsAll(A, "pfx"))
        },
        prefixedCSS = ModernizrProto.prefixedCSS = function (A) {
            var e = prefixed(A);
            return e && domToCSS(e)
        };
    Modernizr.addTest("batteryapi", !!prefixed("battery", navigator), {
        aliases: ["battery-api"]
    });
    var crypto = prefixed("crypto", window);
    Modernizr.addTest("crypto", !!prefixed("subtle", crypto)), Modernizr.addTest("dart", !!prefixed("startDart", navigator)), Modernizr.addTest("forcetouch", function () {
        return hasEvent(prefixed("mouseforcewillbegin", window, !1), window) ? MouseEvent.WEBKIT_FORCE_AT_MOUSE_DOWN && MouseEvent.WEBKIT_FORCE_AT_FORCE_MOUSE_DOWN : !1
    }), Modernizr.addTest("fullscreen", !(!prefixed("exitFullscreen", document, !1) && !prefixed("cancelFullScreen", document, !1))), Modernizr.addTest("gamepads", !!prefixed("getGamepads", navigator));
    var indexeddb;
    try {
        indexeddb = prefixed("indexedDB", window)
    } catch (e) {}
    Modernizr.addTest("indexeddb", !!indexeddb), indexeddb && Modernizr.addTest("indexeddb.deletedatabase", "deleteDatabase" in indexeddb), Modernizr.addAsyncTest(function () {
        var A, e, t, n = "detect-blob-support",
            r = !1;
        try {
            A = prefixed("indexedDB", window)
        } catch (i) {}
        if (!Modernizr.indexeddb || !Modernizr.indexeddb.deletedatabase) return !1;
        try {
            A.deleteDatabase(n).onsuccess = function () {
                e = A.open(n, 1), e.onupgradeneeded = function () {
                    e.result.createObjectStore("store")
                }, e.onsuccess = function () {
                    t = e.result;
                    try {
                        t.transaction("store", "readwrite").objectStore("store").put(new Blob, "key"), r = !0
                    } catch (i) {
                        r = !1
                    } finally {
                        addTest("indexeddbblob", r), t.close(), A.deleteDatabase(n)
                    }
                }
            }
        } catch (i) {
            addTest("indexeddbblob", !1)
        }
    }), Modernizr.addTest("intl", !!prefixed("Intl", window)), Modernizr.addTest("pagevisibility", !!prefixed("hidden", document, !1)), Modernizr.addTest("performance", !!prefixed("performance", window)), Modernizr.addTest("pointerlock", !!prefixed("exitPointerLock", document)), Modernizr.addTest("quotamanagement", function () {
        var A = prefixed("temporaryStorage", navigator),
            e = prefixed("persistentStorage", navigator);
        return !(!A || !e)
    }), Modernizr.addTest("requestanimationframe", !!prefixed("requestAnimationFrame", window), {
        aliases: ["raf"]
    }), Modernizr.addTest("vibrate", !!prefixed("vibrate", navigator)), Modernizr.addTest("webintents", !!prefixed("startActivity", navigator)), Modernizr.addTest("lowbattery", function () {
        var A = .2,
            e = prefixed("battery", navigator);
        return !!(e && !e.charging && e.level <= A)
    });
    var crypto = prefixed("crypto", window),
        supportsGetRandomValues;
    if (crypto && "getRandomValues" in crypto && "Uint32Array" in window) {
        var array = new Uint32Array(10),
            values = crypto.getRandomValues(array);
        supportsGetRandomValues = values && is(values[0], "number")
    }
    Modernizr.addTest("getrandomvalues", !!supportsGetRandomValues), Modernizr.addTest("backgroundblendmode", prefixed("backgroundBlendMode", "text")), Modernizr.addTest("objectfit", !!prefixed("objectFit"), {
        aliases: ["object-fit"]
    }), Modernizr.addTest("wrapflow", function () {
        var A = prefixed("wrapFlow");
        if (!A || isSVG) return !1;
        var e = A.replace(/([A-Z])/g, function (A, e) {
                return "-" + e.toLowerCase()
            }).replace(/^ms-/, "-ms-"),
            t = createElement("div"),
            n = createElement("div"),
            r = createElement("span");
        n.style.cssText = "position: absolute; left: 50px; width: 100px; height: 20px;" + e + ":end;", r.innerText = "X", t.appendChild(n), t.appendChild(r), docElement.appendChild(t);
        var i = r.offsetLeft;
        return docElement.removeChild(t), n = r = t = undefined, 150 == i
    }), Modernizr.addTest("filesystem", !!prefixed("requestFileSystem", window)), Modernizr.addTest("requestautocomplete", !!prefixed("requestAutocomplete", createElement("form"))), Modernizr.addTest("speechrecognition", !!prefixed("SpeechRecognition", window));
    var url = prefixed("URL", window, !1);
    url = url && window[url], Modernizr.addTest("bloburls", url && "revokeObjectURL" in url && "createObjectURL" in url), Modernizr.addAsyncTest(function () {
            function A() {
                addTest("transferables", !1), e()
            }

            function e() {
                d && URL.revokeObjectURL(d), a && a.terminate(), r && clearTimeout(r)
            }
            var t = !!(Modernizr.blobconstructor && Modernizr.bloburls && Modernizr.webworkers && Modernizr.typedarrays);
            if (!t) return addTest("transferables", !1);
            try {
                var n, r, i = 'var hello = "world"',
                    o = new Blob([i], {
                        type: "text/javascript"
                    }),
                    d = URL.createObjectURL(o),
                    a = new Worker(d);
                a.onerror = A, r = setTimeout(A, 200), n = new ArrayBuffer(1), a.postMessage(n, [n]), addTest("transferables", 0 === n.byteLength), e()
            } catch (s) {
                A()
            }
        }), Modernizr.addTest("getusermedia", !!prefixed("getUserMedia", navigator)), Modernizr.addTest("peerconnection", !!prefixed("RTCPeerConnection", window)), Modernizr.addTest("datachannel", function () {
            if (!Modernizr.peerconnection) return !1;
            for (var A = 0, e = domPrefixes.length; e > A; A++) {
                var t = window[domPrefixes[A] + "RTCPeerConnection"];
                if (t) {
                    var n = new t({
                        iceServers: [{
                            url: "stun:0"
                        }]
                    });
                    return "createDataChannel" in n
                }
            }
            return !1
        }), Modernizr.addTest("matchmedia", !!prefixed("matchMedia", window)), ModernizrProto.testAllProps = testAllProps, Modernizr.addTest("ligatures", testAllProps("fontFeatureSettings", '"liga" 1')), Modernizr.addTest("cssanimations", testAllProps("animationName", "a", !0)), Modernizr.addTest("csspseudoanimations", function () {
            var A = !1;
            if (!Modernizr.cssanimations || !window.getComputedStyle) return A;
            var e = ["@", Modernizr._prefixes.join("keyframes csspseudoanimations { from { font-size: 10px; } }@").replace(/\@$/, ""), '#modernizr:before { content:" "; font-size:5px;', Modernizr._prefixes.join("animation:csspseudoanimations 1ms infinite;"), "}"].join("");
            return Modernizr.testStyles(e, function (e) {
                A = "10px" === window.getComputedStyle(e, ":before").getPropertyValue("font-size")
            }), A
        }), Modernizr.addTest("appearance", testAllProps("appearance")), Modernizr.addTest("backdropfilter", testAllProps("backdropFilter")), Modernizr.addTest("backgroundcliptext", function () {
            return testAllProps("backgroundClip", "text")
        }), Modernizr.addTest("bgpositionxy", function () {
            return testAllProps("backgroundPositionX", "3px", !0) && testAllProps("backgroundPositionY", "5px", !0)
        }), Modernizr.addTest("bgrepeatround", testAllProps("backgroundRepeat", "round")), Modernizr.addTest("bgrepeatspace", testAllProps("backgroundRepeat", "space")), Modernizr.addTest("backgroundsize", testAllProps("backgroundSize", "100%", !0)), Modernizr.addTest("bgsizecover", testAllProps("backgroundSize", "cover")), Modernizr.addTest("borderimage", testAllProps("borderImage", "url() 1", !0)), Modernizr.addTest("borderradius", testAllProps("borderRadius", "0px", !0)), Modernizr.addTest("boxshadow", testAllProps("boxShadow", "1px 1px", !0)), Modernizr.addTest("boxsizing", testAllProps("boxSizing", "border-box", !0) && (document.documentMode === undefined || document.documentMode > 7)),
        function () {
            Modernizr.addTest("csscolumns", function () {
                var A = !1,
                    e = testAllProps("columnCount");
                try {
                    (A = !!e) && (A = new Boolean(A))
                } catch (t) {}
                return A
            });
            for (var A, e, t = ["Width", "Span", "Fill", "Gap", "Rule", "RuleColor", "RuleStyle", "RuleWidth", "BreakBefore", "BreakAfter", "BreakInside"], n = 0; n < t.length; n++) A = t[n].toLowerCase(), e = testAllProps("column" + t[n]), ("breakbefore" === A || "breakafter" === A || "breakinside" == A) && (e = e || testAllProps(t[n])), Modernizr.addTest("csscolumns." + A, e)
        }(), Modernizr.addTest("displayrunin", testAllProps("display", "run-in"), {
            aliases: ["display-runin"]
        }), Modernizr.addTest("ellipsis", testAllProps("textOverflow", "ellipsis")), Modernizr.addTest("cssfilters", function () {
            if (Modernizr.supports) return testAllProps("filter", "blur(2px)");
            var A = createElement("a");
            return A.style.cssText = prefixes.join("filter:blur(2px); "), !!A.style.length && (document.documentMode === undefined || document.documentMode > 9)
        }), Modernizr.addTest("flexbox", testAllProps("flexBasis", "1px", !0)), Modernizr.addTest("flexboxlegacy", testAllProps("boxDirection", "reverse", !0)), Modernizr.addTest("flexboxtweener", testAllProps("flexAlign", "end", !0)), Modernizr.addTest("flexwrap", testAllProps("flexWrap", "wrap", !0)), Modernizr.addAsyncTest(function () {
            function A() {
                function t() {
                    try {
                        var A = createElement("div"),
                            e = createElement("span"),
                            t = A.style,
                            n = 0,
                            r = 0,
                            i = !1,
                            o = document.body.firstElementChild || document.body.firstChild;
                        return A.appendChild(e), e.innerHTML = "Bacon ipsum dolor sit amet jerky velit in culpa hamburger et. Laborum dolor proident, enim dolore duis commodo et strip steak. Salami anim et, veniam consectetur dolore qui tenderloin jowl velit sirloin. Et ad culpa, fatback cillum jowl ball tip ham hock nulla short ribs pariatur aute. Pig pancetta ham bresaola, ut boudin nostrud commodo flank esse cow tongue culpa. Pork belly bresaola enim pig, ea consectetur nisi. Fugiat officia turkey, ea cow jowl pariatur ullamco proident do laborum velit sausage. Magna biltong sint tri-tip commodo sed bacon, esse proident aliquip. Ullamco ham sint fugiat, velit in enim sed mollit nulla cow ut adipisicing nostrud consectetur. Proident dolore beef ribs, laborum nostrud meatball ea laboris rump cupidatat labore culpa. Shankle minim beef, velit sint cupidatat fugiat tenderloin pig et ball tip. Ut cow fatback salami, bacon ball tip et in shank strip steak bresaola. In ut pork belly sed mollit tri-tip magna culpa veniam, short ribs qui in andouille ham consequat. Dolore bacon t-bone, velit short ribs enim strip steak nulla. Voluptate labore ut, biltong swine irure jerky. Cupidatat excepteur aliquip salami dolore. Ball tip strip steak in pork dolor. Ad in esse biltong. Dolore tenderloin exercitation ad pork loin t-bone, dolore in chicken ball tip qui pig. Ut culpa tongue, sint ribeye dolore ex shank voluptate hamburger. Jowl et tempor, boudin pork chop labore ham hock drumstick consectetur tri-tip elit swine meatball chicken ground round. Proident shankle mollit dolore. Shoulder ut duis t-bone quis reprehenderit. Meatloaf dolore minim strip steak, laboris ea aute bacon beef ribs elit shank in veniam drumstick qui. Ex laboris meatball cow tongue pork belly. Ea ball tip reprehenderit pig, sed fatback boudin dolore flank aliquip laboris eu quis. Beef ribs duis beef, cow corned beef adipisicing commodo nisi deserunt exercitation. Cillum dolor t-bone spare ribs, ham hock est sirloin. Brisket irure meatloaf in, boudin pork belly sirloin ball tip. Sirloin sint irure nisi nostrud aliqua. Nostrud nulla aute, enim officia culpa ham hock. Aliqua reprehenderit dolore sunt nostrud sausage, ea boudin pork loin ut t-bone ham tempor. Tri-tip et pancetta drumstick laborum. Ham hock magna do nostrud in proident. Ex ground round fatback, venison non ribeye in.", document.body.insertBefore(A, o), t.cssText = "position:absolute;top:0;left:0;width:5em;text-align:justify;text-justification:newspaper;", n = e.offsetHeight, r = e.offsetWidth, t.cssText = "position:absolute;top:0;left:0;width:5em;text-align:justify;text-justification:newspaper;" + prefixes.join("hyphens:auto; "), i = e.offsetHeight != n || e.offsetWidth != r, document.body.removeChild(A), A.removeChild(e), i
                    } catch (d) {
                        return !1
                    }
                }

                function n(A, e) {
                    try {
                        var t = createElement("div"),
                            n = createElement("span"),
                            r = t.style,
                            i = 0,
                            o = !1,
                            d = !1,
                            a = !1,
                            s = document.body.firstElementChild || document.body.firstChild;
                        return r.cssText = "position:absolute;top:0;left:0;overflow:visible;width:1.25em;", t.appendChild(n), document.body.insertBefore(t, s), n.innerHTML = "mm", i = n.offsetHeight, n.innerHTML = "m" + A + "m", d = n.offsetHeight > i, e ? (n.innerHTML = "m<br />m", i = n.offsetWidth, n.innerHTML = "m" + A + "m", a = n.offsetWidth > i) : a = !0, d === !0 && a === !0 && (o = !0), document.body.removeChild(t), t.removeChild(n), o
                    } catch (l) {
                        return !1
                    }
                }

                function r(A) {
                    try {
                        var e, t = createElement("input"),
                            n = createElement("div"),
                            r = "lebowski",
                            i = !1,
                            o = document.body.firstElementChild || document.body.firstChild;
                        n.innerHTML = r + A + r, document.body.insertBefore(n, o), document.body.insertBefore(t, n), t.setSelectionRange ? (t.focus(), t.setSelectionRange(0, 0)) : t.createTextRange && (e = t.createTextRange(), e.collapse(!0), e.moveEnd("character", 0), e.moveStart("character", 0), e.select());
                        try {
                            window.find ? i = window.find(r + r) : (e = window.self.document.body.createTextRange(), i = e.findText(r + r))
                        } catch (d) {
                            i = !1
                        }
                        return document.body.removeChild(n), document.body.removeChild(t), i
                    } catch (d) {
                        return !1
                    }
                }
                return document.body || document.getElementsByTagName("body")[0] ? (addTest("csshyphens", function () {
                    if (!testAllProps("hyphens", "auto", !0)) return !1;
                    try {
                        return t()
                    } catch (A) {
                        return !1
                    }
                }), addTest("softhyphens", function () {
                    try {
                        return n("&#173;", !0) && n("&#8203;", !1)
                    } catch (A) {
                        return !1
                    }
                }), void addTest("softhyphensfind", function () {
                    try {
                        return r("&#173;") && r("&#8203;")
                    } catch (A) {
                        return !1
                    }
                })) : void setTimeout(A, e)
            }
            var e = 300;
            setTimeout(A, e)
        }), Modernizr.addTest("cssmask", testAllProps("maskRepeat", "repeat-x", !0)), Modernizr.addTest("overflowscrolling", testAllProps("overflowScrolling", "touch", !0)), Modernizr.addTest("cssreflections", testAllProps("boxReflect", "above", !0)), Modernizr.addTest("cssresize", testAllProps("resize", "both", !0)), Modernizr.addTest("scrollsnappoints", testAllProps("scrollSnapType")), Modernizr.addTest("shapes", testAllProps("shapeOutside", "content-box", !0)), Modernizr.addTest("textalignlast", testAllProps("textAlignLast")), Modernizr.addTest("csstransforms", function () {
            return -1 === navigator.userAgent.indexOf("Android 2.") && testAllProps("transform", "scale(1)", !0)
        }), Modernizr.addTest("csstransforms3d", function () {
            var A = !!testAllProps("perspective", "1px", !0),
                e = Modernizr._config.usePrefixes;
            if (A && (!e || "webkitPerspective" in docElement.style)) {
                var t, n = "#modernizr{width:0;height:0}";
                Modernizr.supports ? t = "@supports (perspective: 1px)" : (t = "@media (transform-3d)", e && (t += ",(-webkit-transform-3d)")), t += "{#modernizr{width:7px;height:18px;margin:0;padding:0;border:0}}", testStyles(n + t, function (e) {
                    A = 7 === e.offsetWidth && 18 === e.offsetHeight
                })
            }
            return A
        }), Modernizr.addTest("csstransitions", testAllProps("transition", "all", !0)), Modernizr.addTest("csspseudotransitions", function () {
            var A = !1;
            if (!Modernizr.csstransitions || !window.getComputedStyle) return A;
            var e = '#modernizr:before { content:" "; font-size:5px;' + Modernizr._prefixes.join("transition:0s 100s;") + "}#modernizr.trigger:before { font-size:10px; }";
            return Modernizr.testStyles(e, function (e) {
                window.getComputedStyle(e, ":before").getPropertyValue("font-size"), e.className += "trigger", A = "5px" === window.getComputedStyle(e, ":before").getPropertyValue("font-size")
            }), A
        }), Modernizr.addTest("userselect", testAllProps("userSelect", "none", !0)), testRunner(), setClasses(classes), delete ModernizrProto.addTest, delete ModernizrProto.addAsyncTest;
    for (var i = 0; i < Modernizr._q.length; i++) Modernizr._q[i]();
    window.Modernizr = Modernizr
}(window, document);